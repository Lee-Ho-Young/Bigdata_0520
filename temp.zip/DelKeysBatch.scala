import java.util.Calendar
import redis.clients.jedis.Jedis
import scala.collection.JavaConverters._

object DelKeysBatch {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
		val now = Calendar.getInstance ()
		now.add (Calendar.HOUR_OF_DAY, -2)
		val compare = "%04d%02d%02d%02d%02d" format (
			now.get(Calendar.YEAR)
			, now.get(Calendar.MONTH) + 1
			, now.get(Calendar.DATE)
			, now.get(Calendar.HOUR_OF_DAY)
			, now.get(Calendar.MINUTE))
		println ("Compare : " + compare)
		for (index <- 2 until 15) {
			jedis.select (index)
			val keys = jedis.keys ("*").asScala	
			keys.foreach (one => {
				if (12 < one.length) {
					if (one.substring (0, 12) <= compare) {
						jedis.del (one)
//						println ("Delete Key : " + one)
					}
				}
			})
		}
        jedis.close ();
    }
}
