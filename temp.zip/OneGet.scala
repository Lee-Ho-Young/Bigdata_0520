import redis.clients.jedis.Jedis

object OneGet {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
        var check = true
        var map = new java.util.HashMap[String, String]()
        var startTime = System.currentTimeMillis ()
        val limit = args (0).toInt
		jedis.select (2)
/*
		var parameter ing] = List[String] ()
       	parameter :+ "20190416142-skt-nimsdrwas2-IMS2_3"
		parameter :+ " 20190416142-skt-smtpwas2-TRX2_1"
*/
/*
		val parameter = Seq[String] ()
		parameter +: "20190416143-skt-notwpwas2\n-mtwdServer22"
		parameter +: "20190416142-skt-smtdrwas1\n-SMT1_2"
*/
/*
		val parameter = new String [2]
		parameter (0) = "20190416143-skt-notwpwas2\n-mtwdServer22"
		parameter (1) = "20190416142-skt-smtdrwas1\n-SMT1_2"

		val parameter : List[String] = List ()
		parameter :+ "20190416143-skt-notwpwas2\n-mtwdServer22"
		parameter :+ "20190416142-skt-smtdrwas1\n-SMT1_2"
*/

		val parameter = jedis.keys ("20190416143*")
//		val result = jedis.mget ("20190416143-skt-notwpwas2\n-mtwdServer22", "20190416142-skt-smtdrwas1\n-SMT1_2")
      	val result = jedis.mget (parameter.toArray)
        println ("Result : " + result)
        jedis.close ();
    }
}
