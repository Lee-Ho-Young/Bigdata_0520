import redis.clients.jedis.Jedis
import scala.collection.JavaConverters._

object CountKeys {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
        var check = true
        var map = new java.util.HashMap[String, String]()
        var startTime = System.currentTimeMillis ()
		jedis.select (args (0).toInt)
		println ("args (0) : " + args (0))
		val keys = jedis.keys (args(1))

		println ("Key'Count : " + keys.size)
//		keys.foreach (one => jedis.del (one))
        jedis.close ();
    }
}
