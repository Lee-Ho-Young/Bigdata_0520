import	scala.util.parsing.json._

object JSONTest {
	def main (args : Array [String]) {
		val parsed = JSON.parseFull ("""{"Name":"abc", "age":"10"}""")
		var value1 : Option[Any] = Some (0)
		var value2 : Option[Any] = Some (0)
		println (parsed)
		parsed match {
			case Some(e) => {
				val res1 = e.asInstanceOf [Map[String,Any]]
				value2 = res1.get ("age")
				value1 = res1.get ("Name")
				}
			case None => println ("Failed")
		}
		val name = value1.get
		val age = value2.get
		println (name)
		println (age)
//		println (parsed.get ("Name"))
	}
}
