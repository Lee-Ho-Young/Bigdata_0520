import redis.clients.jedis.Jedis
import scala.collection.JavaConverters._

object SelectRedis {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
        var startTime = System.currentTimeMillis ()
        jedis.select (args (0).toInt)
        val keys = jedis.keys (args(1)).asScala
        keys.foreach (one => {
            val list = jedis.lrange (one, 0, -1).asScala
            list.foreach (item => {
                val value = item.split ("=")
//              if (value(0) == "os")
//                  println (value(1))
            })
        })
        var finishTime = System.currentTimeMillis ()
        println ("Elapsed Time : " + (finishTime - startTime).toString)
        jedis.close ();
    }
}

