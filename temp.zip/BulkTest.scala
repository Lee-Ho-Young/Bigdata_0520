import redis.clients.jedis.Jedis

object BulkTest {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
        var check = true
        var map = new java.util.HashMap[String, String]()
        var startTime = System.currentTimeMillis ()
        val limit = args (0).toInt
        var result : String = ""
        for (i <- 1 to limit) {
            map.clear ()
            map.put ("name", "server" + i.toString ())
            map.put ("cpu", (i % 100).toString ())
            map.put ("memory", (i % 100).toString ())
            map.put ("thread", (i % 100).toString ())
            result = jedis.hmset ("server" + i, map)
        }
        var finishTime = System.currentTimeMillis ()
        System.out.println ("HMSet Elapsed Time : " + (finishTime - startTime) / 1000f + "초")
        startTime = System.currentTimeMillis ()
        for (i <- 1 to limit) {
            jedis.hmget ("server" + i.toString (), "name", "cpu", "memory")
        }
        System.out.println ("Result : " + result)
        finishTime = System.currentTimeMillis ()
        System.out.println ("HMGet Elapsed Time : " + (finishTime - startTime) / 1000f + "초")
        for (i <- 1 to limit) {
            jedis.del ("server" + i.toString ())
        }
        jedis.close ();
    }
}
