package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.io.BufferedWriter
import	java.io.OutputStreamWriter
import	java.net.Socket
import	java.net.InetAddress
import	java.util.Calendar
import	java.util.Properties

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import	scala.collection.JavaConverters._

import	scala.util.parsing.json._
import	redis.clients.jedis.Jedis

object	OntuneLastPerf {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	var redisKey : String = ""
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.warn ("----------> start : OntuneLastPerf")
		val spark = SparkSession.builder ()
					.appName ("OntuneLastPerf")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.warn ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-ontunedb1-lastperf")
		consumer.subscribe (topics.asJava)

		val jedis = new Jedis ("127.0.0.1", 6379)
		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var stat_date = ""
		var hst_nm = ""
		var nick_name = ""
		var net_in = ""
		var net_out = ""

		var tryCount = 3
		
		var offset = ""

		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val current = selectOneHour (sc, currentDate, hour, jedis,spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), jedis, spark)
		var medianValue = current.union (next)
		while (0 < count) {
			var arrayLastPerf : List [(String, String, String, String, String, String, String, String)] = List ()

			tryCount = 3
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(1000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					for (record <- records.asScala) {
						val jsonString = JSON.parseFull (record.value ())
						nick_name = ""
						net_in = ""
						net_out = ""

						jsonString match {
							case Some (e) => {
								val result = e.asInstanceOf [Map[String, Any]]
								val sys = result.get ("sys")
								val user = result.get ("user")
								val wait = result.get ("wait")
								val filesystemin = result.get ("filesystemin")
								val filesystemout = result.get ("filesystemout")
								val stat_date = result.get ("ontunetime")
								arrayLastPerf = arrayLastPerf :+ (
												 convertDate (stat_date)
												 , result.get ("hostname").get.toString
												 , computeCpu (sys, user, wait).toString
												 , percentage (result.get ("memoryused")).toString
												 , percentage (result.get ("swapused")).toString
												 , result.get ("diskiorate").get.toString
												 , computeFileSystem (filesystemin, filesystemout).toString
												 , result.get ("networkiorate").get.toString) 
							}
							case None => logger.warn ("Failed")
						}
					}
					tryCount = 0
				}
			}
			processOntuneLastPerf (sc, logger, jedis, arrayLastPerf, medianValue)
			commitSync (consumer)
			count -= 1

			val cal = Calendar.getInstance ()
			if (hour != cal.get (Calendar.HOUR_OF_DAY)
			 && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get (Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, cal.get (Calendar.HOUR_OF_DAY), jedis, spark)
				medianValue = next.union (next1)
				next = next1
			}
		}	
		consumer.close ()
		sc.stop ()
		logger.warn ("----------> finish : OntuneLastPerf")
	}

	// Ontune - LastPerf 처리
	def processOntuneLastPerf (sc:SparkContext
							   , logger:org.apache.log4j.Logger
							   , jedis:redis.clients.jedis.Jedis
						 	   , arrayLastPerf:List[(String,String,String,String,String,String,String,String)]
							   , medianValue:org.apache.spark.rdd.RDD [(String, (String,String,String,String,String,String))]) 
		: Unit = {
		val parallel = sc.parallelize (arrayLastPerf)

		// Pair RDD 생성
		var rdd = parallel.map (one => (one._1 + "|" + one._2, (one._3, one._4, one._5, one._6, one._7, one._8)))

		var max = rdd.reduceByKey ((v1, v2) => v1)
		logger.warn ("processOntuneLastPerf : max'size : " + max.count)
		val join = max.join (medianValue)
		if (join.count == 0) {
			max.collect.foreach (one => logger.warn ("-------- join == 0 | " + one))
//			medianValue.collect.foreach (one => logger.warn ("----- median " + one))
		}

		sendOntuneLastPerf (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2._1.toDouble < x._2._1._1.toDouble)			// cpu
			 || (x._2._2._2.toDouble < x._2._1._2.toDouble)			// memory
			 || (x._2._2._3.toDouble < x._2._1._3.toDouble)			// swap
			 || (x._2._2._4.toDouble < x._2._1._4.toDouble))		// diskio
		})
		sendOntuneFault (logger, jedis, event)
	}

	def convertDate (stat_date : Option[Any]) : String = {
		var cal = Calendar.getInstance
		val date = stat_date.get
		cal.setTimeInMillis (date.##.toLong * 1000)
		cal.add (Calendar.HOUR_OF_DAY, -9)
		("%04d%02d%02d%02d%02d%02d") format (cal.get (Calendar.YEAR)
										, cal.get (Calendar.MONTH) + 1		
										, cal.get (Calendar.DAY_OF_MONTH)
										, cal.get (Calendar.HOUR_OF_DAY)
										, cal.get (Calendar.MINUTE)
										, cal.get (Calendar.SECOND))
	}

	def computeCpu (sys:Option[Any], user:Option[Any], wait:Option[Any]) : Int = {
		val sysCpu = sys.get
		val userCpu = user.get
		val waitCpu = wait.get
		(sysCpu.## + userCpu.## + waitCpu.##) / 100
	}

	def computeFileSystem (filesystemin:Option[Any], filesystemout:Option[Any]) : Int = {
		val in = filesystemin.get
		val out = filesystemout.get
		in.## + out.##
	}

	def percentage (value:Option[Any]) : Int = {
		val result = value.get
		result.## / 100
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.warn ("CommitFailedException : " + e)
		}
	}

	def sendOntuneLastPerf (logger:org.apache.log4j.Logger
							, jedis:redis.clients.jedis.Jedis
					 	    , join:org.apache.spark.rdd.RDD [(String, ((String, String, String, String, String, String), (String, String, String, String, String, String)))]) : Unit = {
		if (join.count != 0) {
			val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
			val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream))
			logger.warn ("OntuneLastPerf'join : " + join.count)

			jedis.select (7)					// Ontune Last Perf 측정값
			join.collect.foreach (one => {
				val key = one._1
				val value = "\"Topic\":\"1-ontunedb1-lastperf\",\"cpu\":\"" + one._2._1._1 + "\",\"avg_cpu\":\"" + one._2._2._1 + "\",\"mem\":\"" + one._2._1._2 + "\",\"avg_mem\":\"" + one._2._2._2 + "\",\"swap_used\":\"" + one._2._1._3 + "\",\"avg_swap_used\":\"" + one._2._2._3 + "\",\"disk_io\":\"" + one._2._1._4 + "\",\"avg_disk_io\":\"" + one._2._2._4 + "\""
				jedis.rpush (key, value)
				val split = one._1.split ("[|]+")
				writer.write ("{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\"," + value + "}\n")
				writer.flush ()
			})

			writer.close ()
			socket.close ()
		}
	}
	
	def sendOntuneFault (logger:org.apache.log4j.Logger
					     , jedis:redis.clients.jedis.Jedis
					     , event:org.apache.spark.rdd.RDD [(String, ((String, String, String, String, String, String),(String, String, String, String, String, String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

		jedis.select (2)                        // 2번은 Ontune 실시간 장애

		if (event.count != 0) {
			logger.warn ("sendOntuneFalut'event : " + event.count)

			event.collect.foreach (one => { 
				val key = one._1
				var value : String = ""
				if (one._2._2._1.toDouble < one._2._1._1.toDouble) {
					value = "CPU 측정값(" + one._2._1._1 + ")이 중간값(" + one._2._2._1 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._2.toDouble < one._2._1._2.toDouble) {
					value = "Memory 측정값(" + one._2._1._2 + ")이 중간값(" + one._2._2._2 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._3.toDouble < one._2._1._3.toDouble) {
					value = "SWAP 측정값(" + one._2._1._3 + ")이 중간값(" + one._2._2._3 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._4.toDouble < one._2._1._4.toDouble) {
					value = "Disk IO Rate 측정값(" + one._2._1._4 + ")이 중간값(" + one._2._2._4 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
			})

			writer.close ()
			socket.close ()
		}
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
				     , jedis:redis.clients.jedis.Jedis
				     , writer:BufferedWriter
				     , key:String
				     , value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
		writer.write ( "{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\"," + "\"source\":\"Ontune\",\"Topic\":\1-ontunedb1-eventinfo\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (key + "," + value)
	}

	def selectOneHour (sc:SparkContext
					   , calendar:Calendar
					   , hour:Int
					   , jedis:redis.clients.jedis.Jedis
					   , spark:org.apache.spark.sql.SparkSession)
					   : org.apache.spark.rdd.RDD [(String, (String, String, String, String, String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-ontunedb1-lastperf/" + date)
		val dataFrame = lines.select ("key", "cpu", "mem", "swap", "diskio", "file", "networkio")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString, one(3).toString, one(4).toString, one(5).toString, one(6).toString)))
		logger.warn ("selectOneHour : rdd1'size : " + rdd1.count)
		rdd1
	}
}
