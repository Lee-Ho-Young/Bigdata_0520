package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import	java.util.Calendar
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter
import  java.net.InetAddress
import  java.net.Socket
import  redis.clients.jedis.Jedis

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import	scala.collection.JavaConverters._

object	AnycatcherFault {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.info ("----------> start : Anycatcher-Fault")
		val spark = SparkSession.builder ()
					.appName ("Anycatcher-Fault")
					.master ("local")
					.getOrCreate ()

		val sc = spark.sparkContext
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (6000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.info ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-anycatcher1-fault")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		var count = args (0).toInt
		var cnt = "0"
		var stat_date = ""
		var arrayFault : List [(String, String)] = List ()
		var tryCount = 2

		while (0 < count) {
			tryCount = 2
			while (0 < tryCount) {
				logger.info ("I'm waiting......" + tryCount)
				val records = consumer.poll(10000)
	//			logger.info ("records.count......" + records.count)
				for (record <- records.asScala) {
//					logger.warn (record.value ())
					val value = record.value ().split (" ")
					val message = value(2).split (",")
					var contents = ""
					if (message.size == 8)
						contents = "[" +  message (7)
					for (index <- 3 to (value.size - 1))
						contents += " " + value (index)
					
					arrayFault = arrayFault :+ (
						message (0)													// stat_date
						, "\"hst_nm\":\"" + message (1)								// hst_nm
						+ "\",\"source\":\"anycatcher"								// source
						+ "\",\"search_type\":\"" + message (2)						// search_type
						+ "\",\"search_name\":\"" + message (3)						// search_name
						+ "\",\"err_id\":\"" + message (4)							// err_id
						+ "\",\"err_code\":\"" + message (5)						// err_code
						+ "\",\"status\":\"" + message (6)							// status
						+ "\",\"err_contents\":\"" + contents.substring (1) + "\"")	// err_contents
				}
				if (records.count == 0)
					tryCount = 2
				else {
					processAnycatcherFault (sc, arrayFault)
					commitSync (consumer)
	
					logger.warn ("-------> Record 수 : " + arrayFault.size + ", count : " + count)
					arrayFault = List()
					tryCount = 0
				}
				count -= 1
				logger.warn ("count : " + count)
			}
		}	
		consumer.close ()
		sc.stop ()
		logger.info ("----------> finish : Anycatcher-Fault")
	}

	def processAnycatcherFault (sc : SparkContext
								, arrayFault : List [(String, String)])
								: Unit = {
		var parallel = sc.parallelize (arrayFault)

		// errorCode로 중복 제거
		var rdd = parallel.map (one => (one._1, one))

        val jedis = new Jedis ("127.0.0.1", 6379)
        jedis.select (1)                        // 0~15 중 1번은 실시간 Event

        val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
        val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

        rdd.sortByKey ().collect.foreach (one => {
            val key = one._2._1
            val value = one._2._2
            jedis.rpush (key, value)
            writer.write ("{\"event_time\":\"" + key + "\",\"Topic\":\"1-anycatcher1-fault\"," + value + "}\n")
            logger.warn (key + "," + value)
        })
		writer.flush ();

		writer.close
		socket.close
		jedis.close
		logger.warn ("rdd'size : " + rdd.count)
	}

    // 2019-04-23T03:55:00.559Z Date를 20180423035500으로 변환
	// 사용 안함.
    def convertDate (stat_date : String) : String = {
		val year = stat_date.substring (0, 4).toInt			// Year
		var month = stat_date.substring (5, 7).toInt		// Month
		val day = stat_date.substring (8, 10).toInt			// Day
		val hour = stat_date.substring (11, 13).toInt		// Hour
		val minute = stat_date.substring (14, 16).toInt		// Minute
		val second = stat_date.substring (17, 19).toInt		// Second

		val	cal = Calendar.getInstance ()
		cal.set (Calendar.YEAR, (year))
		month -= 1
		cal.set (Calendar.MONTH, (month))
		cal.set (Calendar.DAY_OF_MONTH, (day))
		cal.set (Calendar.HOUR_OF_DAY, (hour))
		cal.set (Calendar.MINUTE, (minute))
		cal.set (Calendar.SECOND, (second))
		if (0 <= stat_date.indexOf ("Z")) 
			cal.add (Calendar.HOUR_OF_DAY, 9)			// Z : Hour + 9
		
		("%04d%02d%02d%02d%02d%02d") format (
			cal.get (Calendar.YEAR)
			, (cal.get (Calendar.MONTH) + 1)
			, cal.get (Calendar.DAY_OF_MONTH)
			, cal.get (Calendar.HOUR_OF_DAY)
			, cal.get (Calendar.MINUTE)
			, cal.get (Calendar.SECOND))
    }

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.info ("CommitFailedException : " + e)
		}
	}
}
