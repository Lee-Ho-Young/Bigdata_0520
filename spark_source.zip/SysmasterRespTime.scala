package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import  java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import  org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import  redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

object	SysmasterRespTime {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.warn ("----------> start : SysmasterRespTime")
		val spark = SparkSession.builder ()
					.appName ("SysmasterRespTime")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.warn ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-sysmaster1-resptime")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var instnc = ""
		var hst_nm = ""
		var stat_date = ""

		// RespTime에 관련된 변수 
		var exec_cnt = "0"
		var avg_resp_time = "0"

		var checkTime = ""

		var offset = ""

		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val current = selectOneHour (sc, currentDate, hour, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), spark)
		var medianValue = current.union (next)
		logger.warn (">>>>>>>> medianValue.size : " + medianValue.count);

		val jedis = new Jedis ("127.0.0.1", 6379);

		while (0 < count) {
			// topic Thread 변수
			var arrayRespTime : List [(String, String, String, String, String)] = List ()

			var tryCount = 2
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(1000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					tryCount = 0
					for (record <- records.asScala) {
						offset = record.offset ().toString
						val value = record.value ().replaceAll ("[\n\"{}]", "").split (",")
						stat_date = ""
						instnc = ""
						hst_nm = ""
						avg_resp_time = ""
						exec_cnt = ""

						for (one <- value) {
							val item = one.split (":")
							item(0) match {
								case "exec_cnt" => exec_cnt = item(1)
								case "avg_resp_time" => avg_resp_time = item(1)
								case "instnc" => instnc = item(1)
								case "hst_nm" => hst_nm = item(1)
								case "stat_date" => {
									stat_date = item(1)
								}
								case _ =>
							}
						}

						arrayRespTime = arrayRespTime :+ (stat_date
													  , hst_nm
													  , instnc
													  , avg_resp_time		// avg_resp_time 값
													  , exec_cnt)			// exec_cnt 값
					}
				}
			}

			processSysmasterRespTime (sc, logger, jedis, arrayRespTime, medianValue)
			commitSync (consumer)

			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY)
			 && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, hour + 1, spark)
				medianValue = next.union (next1)
				next = next1
				logger.warn (">>>>>>>> medianValue.size : " + medianValue.count);
			}
			count -= 1
			logger.warn ("-------> Record 수 : " + arrayRespTime.size + ", offset : " + offset)
		}	
		consumer.close ()
		sc.stop ()
		jedis.close ()
		logger.warn ("----------> finish : SysmasterRespTime")
	}

	// SysmasterRespTime - RespTime 처리
	def processSysmasterRespTime (sc:SparkContext
								, logger:org.apache.log4j.Logger
								, jedis:redis.clients.jedis.Jedis
								, arrayRespTime:List[(String,String,String,String,String)]
								, medianValue:org.apache.spark.rdd.RDD [(String, (String, String))])
		: Unit = {
		val parallel = sc.parallelize (arrayRespTime)

		// Pair RDD 생성
		var rdd = parallel.map (one => {
			(one._1 + "|" + one._2 + "|" + one._3, (one._4, one._5))
		})
		val join = rdd.join (medianValue)
		logger.warn ("processSysmasterRespTime'join : " + join.count)
		if (join.count == 0)
			rdd.collect.foreach (one => logger.warn (">>>>>>>> join == 0 | " + one))
		else 
			sendSysmasterRespTime (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2._1.toDouble < x._2._1._1.toDouble)
			 || (x._2._2._2.toDouble < x._2._1._2.toDouble))
		})
		if (0 < event.count)
			sendSysmasterRespTimeFault (logger, jedis, event)
	}

	def checkHour (hour : Int) : Boolean = {
		val current = Calendar.getInstance ()
		if (hour != current.get (Calendar.HOUR_OF_DAY) && (10 < current.get (Calendar.MINUTE)))
			false
		else
			true
	}

	def selectOneHour (sc:SparkContext
						, calendar:Calendar
						, hour:Int
						, spark:org.apache.spark.sql.SparkSession)
						: org.apache.spark.rdd.RDD [(String, (String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-sysmaster1-resptime/" + date)
		val dataFrame = lines.select ("key", "avg_resp_time", "exec_cnt")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}	

	def sendSysmasterRespTime (logger:org.apache.log4j.Logger
							, jedis:redis.clients.jedis.Jedis
							, join:org.apache.spark.rdd.RDD [(String, ((String, String), (String,String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		logger.warn ("SysmasterRespTime'join : " + join.count)

		jedis.select (9)			// select 9번 SysmasterRespTime 측정값
		join.collect.foreach (one => {
			val key = one._1
			val value = "\"avg_resp_time\":\"" + one._2._1._1 + "\",\"avg_avg_resp_time\":\"" + one._2._2._1 + "\",\"exec_cnt\":\"" + one._2._1._2 + "\",\"avg_exec_cnt\":\"" + one._2._2._2 + "\""
			jedis.rpush (key, value)
			val split = one._1.split ("[|]+")
			writer.write ("{\"event_time\":\"" + split(0) + "\",\"type\":\"real\",\"hst_nm\":\"" + split(1) + "\",\"instnc\":\"" + split(2) + "\",\"Topic\":\"1-sysmaster1-resptime\"," + value + "}\n")
		})
		writer.close ()
		socket.close ()
	}

	def sendSysmasterRespTimeFault (logger:org.apache.log4j.Logger
								  , jedis:redis.clients.jedis.Jedis
								  , event:org.apache.spark.rdd.RDD [(String, ((String, String), (String,String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		jedis.select (1)                        // 1번 Anycatcher 실시간 장애

		logger.warn ("sendSysmasterRespTimeFault'event : " + event.count)

		event.collect.foreach (one => {
			val key = one._1
			var value : String = ""
			if (one._2._2._1.toDouble < one._2._1._1.toDouble) {
				value = "avg_resp_time 측정값(" + one._2._1._1.toDouble + ")이 중간값(" + one._2._2._1.toDouble + ")보다 큽니다."
				saveDbAndUi (logger, jedis, writer, key, value)
			}
			if (one._2._2._2.toDouble < one._2._1._2.toDouble) {
				value = "exec_cnt 측정값(" + one._2._1._2.toDouble + ")이 중간값(" + one._2._2._2.toDouble + ")보다 큽니다."
				saveDbAndUi (logger, jedis, writer, key, value)
			}
		})
		writer.close ()
		socket.close ()
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, writer:BufferedWriter
					, key:String
					, value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
		writer.write ( "{\"event_time\":\"" + split(0) + "\",\"Topic\":\"1-sysmaster1-fault\",\"hst_nm\":\"" + split(1) + "\"," + "\"source\":\"Sysmaster\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (key + "," + value)
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.warn ("CommitFailedException : " + e)
		}
	}
}
