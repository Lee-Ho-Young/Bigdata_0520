package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import  java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import  org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import  redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

/*
 *	CSP_RESP_TIME_DELAY : CSP 서버들 대상(skt-csp*)
 *						: exec_cnt가 10건(절대값)초과이면서 
 *	                    : resp_time이 2주 최대값 + 700보다 초과하고
 *	                    : 초과한 회수가 최근 10분간 30회 초과인 경우
 *
 *	RESP_TIME_DELAY : 모든 서버 대상
 *						: exec_cnt가 10건(절대값)초과이면서 
 *	                    : resp_time이 2주 최대값 + 2500보다 초과하고
 *	                    : 초과한 회수가 최근 5분간 15회 초과인 경우
 */
object	ComplexRespTime {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.warn ("----------> start : ComplexRespTime")
		val spark = SparkSession.builder ()
					.appName ("ComplexRespTime")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "ComplexRespTime")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.warn ("----------> group_id : ComplexRespTime")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-sysmaster1-resptime")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var instnc = ""
		var hst_nm = ""
		var stat_date = ""

		// RespTime에 관련된 변수 
		var exec_cnt = "0"
		var avg_resp_time = "0"

		var offset = ""

		// 7주 중간값 수집
		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		currentDate.add (Calendar.HOUR_OF_DAY, -1)			// -1시간
		val tmp = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)			// 0 시간
		val current = selectOneHour (sc, currentDate, hour, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)			// +1시간
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), spark)
		val nextTmp = current.union (tmp)
		var medianValue = next.union (nextTmp)
		logger.warn (">>>>>>>> medianValue.size : " + medianValue.count);

		val jedis = new Jedis ("127.0.0.1", 6379);

		val tmpRdd = List (("20190102030405", "hst_nm", "instnc", "0", "0"))
		var rdd = sc.parallelize (tmpRdd)
		var rddCsp = sc.parallelize (tmpRdd)

		var baseDate:String = ""
		var nextDate:String = ""

		while (0 < count) {
			var arrayRespTime : List [(String, String, String, String, String)] = List ()
			var arrayRespTimeCsp : List [(String, String, String, String, String)] = List ()
			var tryCount = 2
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(10000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					tryCount = 0
					for (record <- records.asScala) {
						offset = record.offset ().toString
						val value = record.value ().replaceAll ("[\n\"{}]", "").split (",")
						stat_date = ""
						instnc = ""
						hst_nm = ""
						avg_resp_time = ""
						exec_cnt = ""

						for (one <- value) {
							val item = one.split (":")
							item(0) match {
								case "exec_cnt" => exec_cnt = item(1)
								case "avg_resp_time" => avg_resp_time = item(1)
								case "instnc" => instnc = item(1)
								case "hst_nm" => hst_nm = item(1)
								case "stat_date" => {
									stat_date = item(1)
									if (nextDate < stat_date)
										nextDate
								}
								case _ =>
							}
						}

						if (10 < exec_cnt.toInt) {			// 실행건수가 10초과만 처리
							if (0 <= hst_nm.toUpperCase.indexOf ("SKT-CSP")) {
								arrayRespTimeCsp = arrayRespTimeCsp :+ (stat_date
													  	, hst_nm
													  	, instnc
													  	, avg_resp_time		// avg_resp_time 값
													  	, exec_cnt)			// exec_cnt 값
							} else {
								arrayRespTime = arrayRespTime :+ (stat_date
													  	, hst_nm
													  	, instnc
													  	, avg_resp_time		// avg_resp_time 값
													  	, exec_cnt)			// exec_cnt 값
							}
						}
					}
				}
			}

			val arrayPara = sc.parallelize (arrayRespTime)
			logger.warn ("arrayPara'size : " + arrayPara.count)
			rdd = rdd.union (arrayPara)
			val rdd1 = arrayPara.map (one => (one._1, (one)))
			val reduce = rdd1.reduceByKey ((v1, v2) => v1).sortByKey ()
			logger.warn ("reduce'size : " + reduce.count)

			val arrayParaCsp = sc.parallelize (arrayRespTimeCsp)
			rddCsp = rddCsp.union (arrayParaCsp)
			val rddCsp1 = arrayParaCsp.map (one => (one._1, (one)))

			if (0 < reduce.count) {
				val take = reduce.take (1)
				checkComplex (take(0)._1.toString, logger, jedis, medianValue, rdd1)
/**
				reduce.collect.foreach (one => {
					checkComplex (one._1, logger, jedis, medianValue, rdd1)
				})
**/
				logger.warn ("--------- finish 5 Minute ------------")

				checkComplexCsp (take(0)._1, logger, jedis, medianValue, rddCsp1)
//				val reduceCsp = rddCsp1.reduceByKey ((v1, v2) => v1).sortByKey ()
//				logger.warn ("reduceCsp'size : " + reduce.count)
/**
				reduce.collect.foreach (one => {
					checkComplexCsp (one._1, logger, jedis, medianValue, rddCsp1)
				})
**/
				logger.warn ("--------- finish 10 Minute ------------")

				// 20분 지난 데이터 filter
				logger.warn (">>>>>>> take : " + take(0)._1.toString)
				val filterDate = beforeMinutes (take(0)._1.toString, - 20)
				logger.warn ("-------- before rdd filter : " + rdd.count + ", filterDate : " + filterDate)
				rdd = rdd.filter (one => (filterDate < one._1))
				logger.warn ("======== after rdd filter : " + rdd.count)

				logger.warn ("-------- before rddcsp filter : " + rddCsp.count)
				rddCsp = rddCsp.filter (one => (filterDate < one._1))
				logger.warn ("-------- after rddcsp filter : " + rddCsp.count)
			}

			commitSync (consumer)				// Kafka Commit

			// 시간이 변경된 경우 다음 시간 7주 중간값을 수집
			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY)
			 && (cal.get(Calendar.MINUTE) == 20)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, hour + 1, spark)
				medianValue = next.union (next1)
				next = next1
				logger.warn (">>>>>>>> medianValue.size : " + medianValue.count);
			}
//			count -= 1
			logger.warn ("-------> Record 수 : " + arrayRespTime.size + ", offset : " + offset)
		}	
		consumer.close ()
		sc.stop ()
		jedis.close ()
		logger.warn ("----------> finish : ComplexRespTime")
	}

	// ComplexRespTime - RespTime 처리
	def checkComplex (date:String
					, logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, medianValue:org.apache.spark.rdd.RDD [(String, (String, String))]
					, rdd:org.apache.spark.rdd.RDD [(String, (String, String, String, String, String))])
					: Unit = {

		val start05 = beforeMinutes (date, -5)
		logger.warn ("checkComplex ] start : " + start05 + ", finish : " + date)

		// 최근 5분 데이터 추출
		val dateFilter = rdd.filter (one => {
			(start05 <= one._1 && one._1 <= date)
		})

		// 7주 중간값 비교 (resptime + 2500)보다 큰 경우 filter
		val rdd1 = dateFilter.map (one => (one._2._1 + "|" + one._2._2 + "|" + one._2._3, (one._2._4, one._2._5)))
		val join = rdd1.join (medianValue)
		val event = join.filter (one =>
			((one._2._2._1.toDouble /* + 2500*/) < one._2._1._1.toDouble)
		)
		logger.warn (">>>>>>> event'size : " + event.count)

		// 최근 5분동안 15회 초과
		val map = event.map (one => 
			(one._1.substring (15), (1.toString, one._2._1._1))
		).reduceByKey ((v1, v2) => {
			val count = v1._2(0).toInt + v2._2(0).toInt
			var avgRespTime = v1._2(1).toDouble
			if (v1._2(1).toDouble < v2._2(1).toDouble)			// max avg_resp_time
				avgRespTime = v2._2(1).toDouble	
			(count.toString, avgRespTime.toString)
		})
		.filter (one => (/*15*/ 0 < one._2._1.toInt))				// 15회 이상
		sendComplexRespTimeFault (5, date, logger, jedis, map)
	}

	// ComplexRespTimeCsp - RespTime 처리
	def checkComplexCsp (date:String
					, logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, medianValue:org.apache.spark.rdd.RDD [(String, (String, String))]
					, rdd:org.apache.spark.rdd.RDD [(String, (String, String, String, String, String))])
					: Unit = {

		val start10 = beforeMinutes (date, -10)
		logger.warn ("checkComplexCsp ] start : " + start10 + ", finish : " + date)

		// 최근 10분 데이터 추출
		val dateFilter = rdd.filter (one => {
			(start10 <= one._1 && one._1 <= date) 
		})

		// 7주 중간값 비교 (resptime + 700)보다 큰 경우 filter
		val rdd1 = dateFilter.map (one => (one._2._1 + "|" + one._2._2 + "|" + one._2._3, (one._2._4, one._2._5)))
		val join = rdd1.join (medianValue)
		val event = join.filter (one =>
			((one._2._2._1.toDouble /* + 700 */) < one._2._1._1.toDouble)
		)
		logger.warn (">>>>>>> event'size : " + event.count)

		// 최근 10분동안 30회 초과
		val map = event.map (one => 
			(one._1.substring (15), (1.toString, one._2._1._1))
		).reduceByKey ((v1, v2) => {
			var count = v1._2(0).toInt + v2._2(0).toInt
			var avgRespTime = v1._2(1).toDouble
			if (v1._2(1).toDouble < v2._2(1).toDouble)			// max avg_resp_time
				avgRespTime = v2._2(1).toDouble	
			(count.toString, avgRespTime.toString)
		})
		.filter (one => (/* 30 */ 0 < one._2._1.toInt))				// 30회 이상
		sendComplexRespTimeFault (10, date, logger, jedis, map)
	}

	// 이전 시간 조회
	def beforeMinutes (date:String, period:Int) : String = {
		val calendar = Calendar.getInstance ()
		calendar.set (Calendar.YEAR, date.substring (0, 4).toInt)
		calendar.set (Calendar.MONTH, date.substring(4,6).toInt - 1)
		calendar.set (Calendar.DAY_OF_MONTH, date.substring(6,8).toInt)
		calendar.set (Calendar.HOUR_OF_DAY, date.substring(8,10).toInt)
		calendar.set (Calendar.MINUTE, date.substring(10,12).toInt)
		calendar.set (Calendar.SECOND, 0)
		calendar.add (Calendar.MINUTE, period)
		("%04d%02d%02d%02d%02d") format (calendar.get (Calendar.YEAR)
									, calendar.get (Calendar.MONTH) + 1
									, calendar.get (Calendar.DAY_OF_MONTH)
									, calendar.get (Calendar.HOUR_OF_DAY)
									, calendar.get (Calendar.MINUTE))
	}

	def checkHour (hour : Int) : Boolean = {
		val current = Calendar.getInstance ()
		if (hour != current.get (Calendar.HOUR_OF_DAY) && (10 < current.get (Calendar.MINUTE)))
			false
		else
			true
	}

	def selectOneHour (sc:SparkContext
						, calendar:Calendar
						, hour:Int
						, spark:org.apache.spark.sql.SparkSession)
						: org.apache.spark.rdd.RDD [(String, (String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-sysmaster1-resptime/" + date)
		val dataFrame = lines.select ("key", "avg_resp_time", "exec_cnt")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}	

	def sendComplexRespTimeFault (period:Int
								  , date:String
								  , logger:org.apache.log4j.Logger
								  , jedis:redis.clients.jedis.Jedis
								  , rdd:org.apache.spark.rdd.RDD[(String, (String, String))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		jedis.select (1)                        // 1번 Anycatcher 실시간 장애

		logger.warn ("sendComplexRespTimeFault'rdd : " + rdd.count)

		rdd.collect.foreach (one => {
			val tmp = one._1.split ("[|]+")
			val hst_nm = tmp(0)
			val instnc = tmp(1)

			val value = "[WAS 응답 속도 지연 발생] " + hst_nm + "서버 " + instnc + " 인스턴스에서 WAS 응답속도 " + (one._2._2.toDouble / 1000).toString + "초이며, 최근 " + period + "분간 임계치 초과로 점검 필요"
			saveDbAndUi (logger, jedis, writer, hst_nm, instnc, value, date)
		})
		writer.close ()
		socket.close ()
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, writer:BufferedWriter
					, hst_nm:String
					, instnc:String
					, value:String
					, date:String) : Unit = {
		jedis.rpush (hst_nm + "|" + instnc, value)
		writer.write ( "{\"stat_date\":\"" + date + "\",\"Topic\":\"1-sysmaster1-fault\",\"hst_nm\":\"" + hst_nm + "\"," + "\",instnc\":\"" + instnc + "\",source\":\"Sysmaster\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (hst_nm + "|" + instnc + "," + value)
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.warn ("CommitFailedException : " + e)
		}
	}
}
