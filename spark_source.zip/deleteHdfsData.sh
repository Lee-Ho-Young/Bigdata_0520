#!/bin/bash

#delete [/user/flume] data older than 50 days
hdfs dfs -ls /user/flume/kafka-data/*/ | tr -s " " | cut -d' ' -f6-8 | grep "^[0-9]" | awk 'BEGIN{ MIN=72000; LAST=60*MIN; "date +%s" | getline NOW } { cmd="date -d'\''"$1" "$2"'\'' +%s"; cmd | getline WHEN; DIFF=NOW-WHEN; if(DIFF > LAST) { print "Deleting: "$3; }}'  #system("hdfs dfs -rm -r "$3) }}'

#delete [/spark2-history] data older than 10 days
hdfs dfs -ls /spark2-history | tr -s " " | cut -d' ' -f6-8 | grep "^[0-9]" | awk 'BEGIN{ MIN=14400; LAST=60*MIN; "date +%s" | getline NOW } { cmd="date -d'\''"$1" "$2"'\'' +%s"; cmd | getline WHEN; DIFF=NOW-WHEN; if(DIFF > LAST) {print "Deleting: "$3; system("hdfs dfs -rm -r "$3) }}'
