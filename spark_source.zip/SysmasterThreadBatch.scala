package com.skcc.tqms

import java.util.Calendar
import scala.io.Source.fromFile
import scala.reflect.api.materializeTypeTag

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.AnalysisException
import org.apache.log4j.Logger

import org.apache.spark._

object SysmasterThreadBatch {
	val	BATCH_HOME = "/user/flume/kafka-data/1-sysmaster1-thread/"
	def main(args : Array[String]) {
		@transient lazy val logger = Logger.getLogger(getClass.getName)

		var check = true

		val spark = SparkSession.builder()
			.appName("SysmasterThreadBatch")
			.master ("yarn")
			.getOrCreate()
  
		import spark.implicits._
		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
      
		val tmp = List (("", "000000000", "0", "0", "0", "0", "0", "0"))
		val para = sc.parallelize (tmp)

	    for (index <- 0 to 23) {
			var aggregate = para.map (one => (one._2, List(one._3, one._4)))
			val currentDate = Calendar.getInstance ()
			currentDate.add (Calendar.DAY_OF_MONTH, 1)			// +1일
			val baseDate = getBaseDate (currentDate)			// Key값으로 사용

			for (date <- 1 to 7) {
				import org.apache.spark.SparkContext._
				import spark.implicits._
				import spark.sql
				import org.apache.spark.sql.functions._
				currentDate.add (Calendar.DAY_OF_MONTH, -1)		// -1을 -7로 변경 필요
				val tmp1 = collectJsonFile (currentDate, spark, baseDate, logger, changeNumber (index))
				aggregate = aggregate.union (tmp1)
			}
			aggregate = aggregate.aggregateByKey(List[String]()) (
						(x, y) => x ::: List (y.toString)
						, (x1, y1) => x1 ::: y1)
			logger.warn ("--------> aggregate'size : " + aggregate.count)
//			aggregate.collect.foreach (logger.warn)

			val medianRdd = aggregate.map (item => {
				val key = item._1
				if (key != "000000000") {
					val one = item._2.toString
					var maxThreadCnt : List [String] = List ()
					var avgThreadCnt : List [String] = List ()
	
					var regex = "\\]"
					var replace = one.replaceAll ("[List(]", "").replaceAll ("[ )]", "").replaceAll (regex, "")
					var split = replace.split (",")
					for (index <- 0 to (split.length/2 - 1)) {
						maxThreadCnt = maxThreadCnt ::: List (split (index * 2).toString)
						avgThreadCnt = avgThreadCnt ::: List (split (index * 2 + 1).toString)
					}
					val maxThreadCnt7 = median (maxThreadCnt)
					val avgThreadCnt7 = median (avgThreadCnt)
	
					(key, List (maxThreadCnt7.toString, avgThreadCnt7.toString))
				} else
					(key, List (0.toString, 0.toString))
			})
	
			val tmp = medianRdd.map (one => {
				val key = one._1
				val maxThread = one._2(0)
				val avgThread = one._2(1)
				("{\"key\":\"" + key + "\",\"max_thread\":\"" + maxThread + "\",\"avg_thread\":\"" + avgThread + "\"}")
			})
			tmp.saveAsTextFile ("/user/spark/median/1-sysmaster1-thread/" + baseDate + "/" + changeNumber (index))
		}
		sc.stop ()
	}

	// Kafka/토픽 디렉토리 일자별 디렉토리 이름
	def getDirectoryName (calendar:Calendar) : String = {
		("%s%02d%02d") format (calendar.get (Calendar.YEAR).toString.substring (2,4)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 새로운 중간값을 만들 일자의 연도/월/일 지정한다.
	def getBaseDate (calendar:Calendar) : String = {
		("%04d%02d%02d") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 한 개 파일을 JSON 형태로 읽고, RDD로 변환한다.
	def	collectJsonFile (currentDate:Calendar
						, spark:org.apache.spark.sql.SparkSession
						, baseDate:String
						, logger:org.apache.log4j.Logger
						, subDir:String)
						: org.apache.spark.rdd.RDD [(String, List[String])] = {
		var directoryName = getDirectoryName (currentDate) + "/" + subDir

		import spark.implicits._
		var dataFrame : org.apache.spark.sql.DataFrame = List (("00000000000000","0","0","0","0")).toDF ("stat_date", "hst_nm", "instnc", "max_thread", "avg_thread")

		val sc = spark.sparkContext
		val fileList = getAllFiles (BATCH_HOME + directoryName, sc)

		if (0 < fileList.size && (fileList(0) != "")) {
			var cal = Calendar.getInstance ()
			fileList.foreach (one => {
				logger.warn (">>>>>>>>>>>>>> File : " + one + ", baseData : " + baseDate)
				val lines = spark.read.json (one)			// 파일에서 JSON형태로 읽는다.
		
				val columns = lines.columns
				var count = 0
				columns.foreach (one => if (one == "max_thread") count += 1)
				if (0 < count)
					dataFrame = dataFrame.union (lines.select ("stat_date", "hst_nm", "instnc", "max_thread", "avg_thread"))
			})
		}
		val rdd = dataFrame.rdd.filter (one => (one(3) != null && one(4) != null))
		val rdd1 = rdd.map (one => (baseDate + one(0).toString.substring (8) + "|" + one(1) + "|" + one(2), List(one(3).toString, one(4).toString)))
		
		rdd1
	}

	// 지정된 디렉토리안에 있는 모든 파일명을 얻는다.
	def getAllFiles (path:String, sc:SparkContext) : Seq [String] = {
		try {
			val conf = sc.hadoopConfiguration
			val fs = FileSystem.get (conf)
			val files = fs.listStatus (new Path (path))
			files.filter (_.getLen () > 0).map (_.getPath ().toString)
		} catch {
			case e: Exception => Seq ("")
		}
	}

	// 주어진 List에서 중간값을 얻는다.
	def median (list : List[String]) : String = {
		val (lower, upper) = list.sortWith (_<_).splitAt (list.size / 2)
		if (list.size % 2 == 0)
			((lower.last.toDouble + upper.head.toDouble) / 2).toString
		else
			upper.head.toString
	}

	// 숫자를 두자리 수 시간으로 변경한다.
	def changeNumber (hour : Int) : String = {
		("%02d" format (hour))
	}
}
