package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import  java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import	redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

object	AnycatcherDiskIo {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	var redisKey : String = ""
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.info ("----------> start : AnycatcherDiskIo")
		val spark = SparkSession.builder ()
					.appName ("AnycatcherDiskIo")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.info ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-anycatcher1-diskio")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var stat_date = ""
		var hst_nm = ""
		var disk_io = ""
		var read = ""
		var avg_disk_use_rate = ""

		var tryCount = 3

/* ------------- Redis 연동 ------------------*/
		val jedis = new Jedis ("127.0.0.1", 6379)
		jedis.select (4)						// 4번은 Anycatcher Disk IO 측정값
		
		var offset = ""
		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val current = selectOneHour (sc, currentDate, hour, jedis, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), jedis, spark)
		var medianValue = current.union (next)

		while (0 < count) {
			// topic diskusage 변수 - stat_date, hst_nm, disk_io, read, avg_disk_use_rate
			var arrayDiskIo : List [(String, String, String, String, String)] = List ()

			tryCount = 3
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(1000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					for (record <- records.asScala) {
						val value = record.value ().replaceAll ("[\n\"{}]", "").split (",")
						disk_io = ""
						read = ""
						avg_disk_use_rate = ""

						var count = 0
						for (one <- value) {
							val item = one.split (",")
							if (0 <= item(0).indexOf ("message:")) {
								val message = item(0).split (":")
								stat_date = message (1)
								count += 1
							} else if (1 <= count && count <= 4) {
								count match {
									case 1 => hst_nm = item(0)
									case 2 => disk_io = item(0)
									case 3 => read = item(0)
									case 4 => avg_disk_use_rate = item(0)
								}
								count += 1
							}
						}
//						logger.info ("stat_date : " + stat_date + ", hst_nm : " + hst_nm + ", disk_io : " + disk_io + ", read : " + read + ", avg_disk_use_rate : " + avg_disk_use_rate)
						arrayDiskIo = arrayDiskIo :+ (stat_date
											  , hst_nm
											  , disk_io
											  , read
											  , avg_disk_use_rate)
					}
					tryCount = 0
				}
			}
			processAnycatcherDiskIo (sc, logger, jedis, arrayDiskIo, medianValue)
			commitSync (consumer)
			count -= 1
			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY)
			 && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, cal.get (Calendar.HOUR_OF_DAY), jedis, spark)
				medianValue = next.union (next1)
				next = next1
			}
		}	
		consumer.close ()
		sc.stop ()
		jedis.close ()
		logger.info ("----------> finish : AnycatcherDiskIo")
	}

	// Anycatcher - diskio 처리
	def processAnycatcherDiskIo (sc:SparkContext
								 , logger:org.apache.log4j.Logger
								 , jedis : Jedis
							 	 , arrayDiskIo:List[(String,String,String,String,String)]
								 , medianValue:org.apache.spark.rdd.RDD[(String, (String, String, String))]) : Unit = {
		val parallel = sc.parallelize (arrayDiskIo)

		// Pair RDD 생성
		var rdd = parallel.map (one => (one._1 + "|" + one._2, (one._3, one._4, one._5)))

		var max = rdd.reduceByKey ((v1, v2) => v1)

		val join = max.join (medianValue)
		if (join.count == 0)
			max.collect.foreach (one => logger.warn (">>>>>> join == 0 | " + one))
		else
			sendAnycatcherDiskIo (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2._1.toInt < x._2._1._1.toInt)
			 || (x._2._2._2.toInt < x._2._1._2.toInt)
			 || (x._2._2._3.toInt < x._2._1._3.toInt))
		})
		sendAnycatcherDiskIoFault (logger, jedis, event)
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.info ("CommitFailedException : " + e)
		}
	}

	def selectOneHour (sc:SparkContext
					   , calendar:Calendar
					   , hour:Int
					   , jedis:redis.clients.jedis.Jedis
					   , spark:org.apache.spark.sql.SparkSession)
					   : org.apache.spark.rdd.RDD [(String, (String, String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH)
				, hour)

		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-anycatcher1-diskio/" + date)
		val dataFrame = lines.select ("key", "disk_io", "read", "avg_disk_use_rate")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString, one(3).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}

	def sendAnycatcherDiskIo (logger:org.apache.log4j.Logger, jedis:redis.clients.jedis.Jedis
						  , join:org.apache.spark.rdd.RDD [(String, ((String, String, String), (String, String, String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		logger.warn ("AnycatcherDiskIo'join : " + join.count)
		jedis.select (4)
		join.collect.foreach (one => {
			val key = one._1
			val value = "\"Topic\":\"1-anycatcher1-diskio\",\"disk_io\":\"" + one._2._1._1 + "\",\"avg_disk_io\":\"" + one._2._2._1 + "\",\"read\":\"" + one._2._1._2 + "\",\"avg_read\":\"" + one._2._2._2 + "\",\"disk_use_rate\":\"" + one._2._1._3+ "\",\"avg_disk_use_rate\":\"" + one._2._2._3 + "\""
			jedis.rpush (key, value)
			val split = one._1.split ("[|]+")
			writer.write ("{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\"," + value + "}\n")
			writer.flush()
		})
		writer.close ()
		socket.close ()
	} 

	def sendAnycatcherDiskIoFault (logger:org.apache.log4j.Logger
							   , jedis:redis.clients.jedis.Jedis
							   , event:org.apache.spark.rdd.RDD [(String, ((String, String, String), (String,String,String)))]) : Unit = {

		if (event.count != 0) {
			val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
			val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

			jedis.select (1)						// 1번 Anycatcher 실시간 장애
			logger.warn (logger)
			logger.warn ("sendAnycatcherOsFault'event : " + event.count)

			event.reduceByKey ((v1, v2) => (v1))
			event.collect.foreach (one => {
				val key = one._1
				var value : String = ""
				if (one._2._2._1.toInt < one._2._1._1.toInt) {
					value = "Disk IO 측정값(" + one._2._1._1 + ")이 중간값(" + one._2._2._1 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._2.toInt < one._2._1._2.toInt) {
					value = "Disk Read 측정값(" + one._2._1._2 + ")이 중간값(" + one._2._2._2 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._3.toInt < one._2._1._3.toInt) {
					value = "Disk Use Rate 측정값(" + one._2._1._3 + ")이 중간값(" + one._2._2._3 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
			})
			writer.close ()
			socket.close ()
		}
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, writer:BufferedWriter
					, key:String
					, value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
        writer.write ( "{\"event_time\":\"" + split(0) + "\",\"Topic\":\"1-anycatcher1-fault\",\"hst_nm\":\"" + split(1) + "\"," + "\"source\":\"anycatcher\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (key + "," + value)
	}
}
