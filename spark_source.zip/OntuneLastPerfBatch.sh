spark-submit --driver-java-options "-Dlog4j.configuration=file:///home/bigdata/spark/log4j.lastperf.properties"  --master yarn --deploy-mode client --executor-memory 20G spark/OntuneLastPerfBatch.jar
