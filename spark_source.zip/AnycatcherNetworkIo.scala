package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import  java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import	redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

object	AnycatcherNetworkIo {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	var redisKey : String = ""
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.info ("----------> start : AnycatcherNetworkIo")
		val spark = SparkSession.builder ()
					.appName ("AnycatcherNetworkIo")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.info ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-anycatcher1-networkio")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var stat_date = ""
		var hst_nm = ""
		var nick_name = ""
		var net_in = ""
		var net_out = ""
		var tryCount = 3
		var offset = ""

		val jedis = new Jedis ("127.0.0.1", 6379);
		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val current = selectOneHour (sc, currentDate, hour, jedis, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), jedis, spark)
		var medianValue = current.union (next)

		while (0 < count) {
			// topic diskusage 변수 - stat_date, hst_nm, nick_name, net_in, net_out
			var arrayNetworkIo : List [(String, String, String, String, String)] = List ()

			tryCount = 3
			while (0 < tryCount) {
				logger.info ("I'm waiting......" + tryCount)
				val records = consumer.poll(10000)
				logger.info ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.info ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					for (record <- records.asScala) {
						val value = record.value ().replaceAll ("[\n\"{}]", "")
						val message = value.substring (value.indexOf ("message:") + 8).split (",")
						nick_name = ""
						net_in = ""
						net_out = ""

						var count = 0
//						logger.info (record)
						for (one <- message) {
							val item = one.split (",")
							count match {
								case 0 => stat_date = item(0)
								case 1 => hst_nm = item(0)
								case 2 => nick_name = item(0)
								case 3 => net_in = item(0)
								case 4 => net_out = item(0)
								case _ =>
							}
							count += 1
						}
//						logger.warn ("stat_date : " + stat_date + ", hst_nm : " + hst_nm + ", nick_name : " + nick_name + ", net_in : " + net_in + ", net_out : " + net_out)
						arrayNetworkIo = arrayNetworkIo :+ (stat_date
											  , hst_nm
											  , nick_name
											  , net_in
											  , net_out)
					}
					tryCount = 0
				}
			}
			processAnycatcherNetworkIo (sc, logger, jedis, arrayNetworkIo, medianValue)
			commitSync (consumer)
			count -= 1

			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY) 
			  && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, cal.get (Calendar.HOUR_OF_DAY), jedis, spark)
				medianValue = next.union (next1)
				next = next1
			}
		}	
		consumer.close ()
		jedis.close ()
		sc.stop ()
		logger.info ("----------> finish : AnycatcherNetworkIo")
	}

	// Anycatcher - NetworkIo 처리
	def processAnycatcherNetworkIo (sc:SparkContext
									, logger:org.apache.log4j.Logger
									, jedis:redis.clients.jedis.Jedis
							 		, arrayNetworkIo:List[(String,String,String,String,String)]
									, medianValue:org.apache.spark.rdd.RDD [(String, (String))]) 
		: Unit = {
		val parallel = sc.parallelize (arrayNetworkIo)

		// Pair RDD 생성(stat_date + "-" + hsn_nm + "-" + nick_name
		var rdd = parallel.map (one => (one._1 + "|" + one._2, ((one._4.toDouble + one._5.toDouble).toString)))

//		logger.warn ("------------- RDD --------------------")
//		rdd.collect.foreach (one => logger.warn(one + ", " + one._1 + ", " +  one._2))
		val max = rdd.reduceByKey ((v1, v2) => ((v1.toDouble + v2.toDouble).toString))
//		logger.warn ("------------- MAX --------------------")
//		max.collect.foreach (logger.warn)
		val join = max.join (medianValue)
		if (join.count == 0)
			max.collect.foreach (one => logger.warn (">>>>>>> join == 0 | " + one))
		else
			sendAnycatcherNetworkIo (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			(x._2._2.toDouble < x._2._1.toDouble)
		})
		sendAnycatcherNetworkIoFault (logger, jedis, event)
	}

	def sendAnycatcherNetworkIo (logger:org.apache.log4j.Logger
								 , jedis:redis.clients.jedis.Jedis
								 , join:org.apache.spark.rdd.RDD [(String, ((String), (String)))])
								 : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

		logger.warn ("AnycatcherOsThread'join : " + join.count)
		jedis.select (6)
		join.collect.foreach (one => {
			val key = one._1
			val value = "\"Topic\":\"1-anycatcher1-networkio\",\"networkio\":\"" + one._2._1 + "\",\"avg_networkio\":\"" + one._2._2 + "\""
			jedis.rpush (key, value)
			val split = one._1.split ("[|]+")
			writer.write ("{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\"," + value + "}\n")
			writer.flush ()
		})
		writer.close ()
		socket.close ()
	}

	def selectOneHour (sc:SparkContext
					   , calendar:Calendar
					   , hour:Int
					   , jedis:redis.clients.jedis.Jedis
					   , spark:org.apache.spark.sql.SparkSession)
					   : org.apache.spark.rdd.RDD [(String, (String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-anycatcher1-networkio/" + date)
		val dataFrame = lines.select ("key", "networkio")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}

	def sendAnycatcherNetworkIoFault (logger:org.apache.log4j.Logger
									  , jedis:redis.clients.jedis.Jedis
									  , event:org.apache.spark.rdd.RDD [(String, ((String), (String)))]) : Unit = {

		logger.warn ("sendAnycatcherOsFault'event : " + event.count)

		if (event.count != 0) {
			val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
			val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
	
			jedis.select (1)                        // 1번 Anycatcher 실시간 장애

			event.reduceByKey ((v1, v2) => (v1))
			event.collect.foreach (one => {
				val key = one._1
				var value : String = ""
				if (one._2._2.toDouble < one._2._1.toDouble) {
					value = "CPU 측정값(" + one._2._1 + ")이 중간값(" + one._2._2 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
			})
			writer.close
			socket.close
		}
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
					 , jedis:redis.clients.jedis.Jedis
					 , writer:BufferedWriter
					 , key:String
					 , value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
		writer.write ("{\"event_time\":\"" + split (0) + "\",\"hst_nm\":\"" + split (1) + "\",\"source\":\"Anycatcher\",\"err_contents\":\"" + value + "\"})\n")
//		logger.warn (key + "," + value)
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.info ("CommitFailedException : " + e)
		}
	}
}
