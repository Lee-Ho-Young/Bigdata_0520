package com.skcc.tqms

import java.util.Calendar
import scala.io.Source.fromFile
import scala.reflect.api.materializeTypeTag

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.AnalysisException
import org.apache.log4j.Logger

import org.apache.spark._

import redis.clients.jedis.Jedis

object OntuneLastPerfBatch {
	val	BATCH_HOME = "/user/flume/kafka-data/1-ontunedb1-lastperf/"
	def main(args : Array[String]) {
		@transient lazy val logger = Logger.getLogger(getClass.getName)

		var check = true

		val spark = SparkSession.builder()
			.appName("OntuneLastPerfBatch")
			.master ("yarn")
			.getOrCreate()
  
		import spark.implicits._
		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
      
		val jedis = new Jedis ("150.2.237.16", 6379)
		jedis.select (13)

		val tmp = List (("000000000", "0", "0", "0", "0", "0", "0"))
		val para = sc.parallelize (tmp)

		for (index <- 0 to 23) {
			var aggregate = para.map (one => (one._1, List(one._2, one._3, one._4, one._5, one._6, one._7)))
			val currentDate = Calendar.getInstance ()
			currentDate.add (Calendar.DAY_OF_MONTH, 1)			// +1일
			val baseDate = getBaseDate (currentDate)			// Key값으로 사용

			for (date <- 1 to 7) {
				import org.apache.spark.SparkContext._
				import spark.implicits._
				import spark.sql
				import org.apache.spark.sql.functions._
				currentDate.add (Calendar.DAY_OF_MONTH, -3)
				val tmp1 = collectJsonFile (currentDate, spark, baseDate, logger, changeNumber (index))
				aggregate = aggregate.union (tmp1)
			}
			aggregate = aggregate.aggregateByKey(List[String]()) (
						(x, y) => x ::: List (y.toString)
						, (x1, y1) => x1 ::: y1)
			logger.warn ("--------> aggregate'size : " + aggregate.count)

			val medianRdd = aggregate.map (item => {
				val key = item._1
				if (key != "000000000") {
					val one = item._2.toString
					var memoryUsed : List [String] = List ()
					var networkIoRate : List [String] = List ()
					var diskIoRate : List [String] = List ()
					var swapUsed : List [String] = List ()
					var cpu : List [String] = List ()
					var fileSystem : List [String] = List ()
	
					var regex = "\\]"
					var replace = one.replaceAll ("[List(]", "").replaceAll ("[ )]", "").replaceAll (regex, "")
					var split = replace.split (",")
					for (index <- 0 to (split.length/6 - 1)) {
						memoryUsed = memoryUsed ::: List (split (index * 6).toString)
						networkIoRate = networkIoRate ::: List (split (index * 6 + 1).toString)
						diskIoRate = diskIoRate ::: List (split (index * 6 + 2).toString)
						swapUsed = swapUsed ::: List (split (index * 6 + 3).toString)
						cpu = cpu ::: List (split (index * 6 + 4).toString)
						fileSystem = fileSystem ::: List (split (index * 6 + 5).toString)
					}
					val memoryUsed7 = median (memoryUsed)
					val networkIoRate7 = median (networkIoRate)
					val diskIoRate7 = median (diskIoRate)
					val swapUsed7 = median (swapUsed)
					val cpu7 = median (cpu)
					val fileSystem7 = median (fileSystem)
	
					(key, List (cpu7.toString, memoryUsed7.toString, swapUsed7.toString, diskIoRate7.toString, fileSystem7.toString, networkIoRate7.toString))
				} else
					(key, List (0.toString, 0.toString, 0.toString, 0.toString, 0.toString, 0.toString))
			})

/**
			saveMemoryDb (jedis, medianRdd)
**/
			val tmp = medianRdd.map (one => {
				val key = one._1
				var cpu = one._2(0)
				var mem = one._2(1)
				var swap = one._2(2)
				var diskIoRate = one._2(3)
				var fileSystem = one._2(4)
				var networkIoRate = one._2(5)
				("{\"key\":\"" + key + "\",\"cpu\":\"" + cpu + "\",\"mem\":\"" + mem + "\",\"swap\":\"" + swap + "\",\"diskio\":\"" + diskIoRate + "\",\"file\":\"" + fileSystem + "\",\"networkio\":\"" + networkIoRate + "\"}")
			})
			tmp.saveAsTextFile ("/user/spark/median/1-ontunedb1-lastperf/" + baseDate + "/" + changeNumber (index))
		}
		sc.stop ()
		jedis.close ()
	}

	// Kafka/토픽 디렉토리 일자별 디렉토리 이름
	def getDirectoryName (calendar:Calendar) : String = {
		("%s%02d%02d") format (calendar.get (Calendar.YEAR).toString.substring (2,4)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 새로운 중간값을 만들 일자의 연도/월/일 지정한다.
	def getBaseDate (calendar:Calendar) : String = {
		("%04d%02d%02d") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 한 개 파일을 JSON 형태로 읽고, RDD로 변환한다.
	def	collectJsonFile (currentDate:Calendar
						 , spark:org.apache.spark.sql.SparkSession
						 , baseDate:String
						 , logger:org.apache.log4j.Logger
						 , subDir:String)
						 : org.apache.spark.rdd.RDD [(String, List[String])] = {
		var directoryName = getDirectoryName (currentDate) + "/" + subDir

		import spark.implicits._
		var dataFrame : org.apache.spark.sql.DataFrame = List (("00000000000000","0","0","0","0","0","0","0","0","0","0")).toDF ("ontunetime", "hostname", "memoryused", "networkiorate","diskiorate", "swapused", "sys", "user", "wait", "filesystemout", "filesystemin")
		val sc = spark.sparkContext
		val fileList = getAllFiles (BATCH_HOME + directoryName, sc)

		var cal = Calendar.getInstance ()
		if (0 < fileList.size && (fileList (0) != "")) {
			val regex = "\\["
			fileList.foreach (one => {
				logger.warn (">>>>>>>>>>>>>> File : " + one + ", baseData : " + baseDate)
				val lines = spark.read.json (one)			// 파일에서 JSON형태로 읽는다.
	
				try {
					dataFrame = dataFrame.union (lines.select ("ontunetime", "hostname", "memoryused", "networkiorate","diskiorate", "swapused", "sys", "user", "wait", "filesystemout", "filesystemin").filter (lines.col("ontunetime").isNotNull))
				} catch {
					case e: AnalysisException => logger.warn ("cannot resolve 'ontunetime....' given input columns")
				}
			})
		}
		val rdd = dataFrame.rdd
//		logger.warn (">>>>>>>>>>>>>> 15시 데이터 <<<<<<<<<<<<<<<<<<")
//		rdd.collect.foreach (logger.warn)
//		logger.warn (">>>>>>>>>>>>>> 15시 데이터(끝) <<<<<<<<<<<<<<<<<<")
		val rdd1 = rdd.map (one => {
			val tmp = one.toString
			val line = tmp.substring (1, tmp.length () - 1).split (",")
			cal.setTimeInMillis (line (0).toString.toLong * 1000)
			cal.add (Calendar.HOUR_OF_DAY, -9)
			val date = ("%02d%02d%02d").format (cal.get (Calendar.HOUR_OF_DAY), cal.get (Calendar.MINUTE), cal.get (Calendar.SECOND))	
			(baseDate + date + "|" + line(1)
				, List ((line(2).toDouble / 100).toString							// memoryUsed
				, line(3)															// networkIoRate
				, line(4)															// diskIoRate
				, (line(5).toDouble / 100).toString									// swapUsed
				, ((line(6).toInt + line(7).toInt + line(8).toInt) / 100).toString	// CPU
				, (line(9).toInt + line(10).toInt).toString))						// FileSystem
		})
		rdd1.reduceByKey ((v1, v2) => v1)
	}

	def	saveMemoryDb (jedis:Jedis
					  , medianRdd : org.apache.spark.rdd.RDD[(String, List[String])]) : Unit = {
		medianRdd.collect.foreach (one => {
			jedis.rpush (one._1, "ontune=" + one._2(0) + "," + one._2(1) + one._2(2) + "," + one._2(3) + "," + one._2(4) + "," + one._2(5))
		})
	}

	// 지정된 디렉토리안에 있는 모든 파일명을 얻는다.
	def getAllFiles (path:String, sc:SparkContext) : Seq [String] = {
		try {
			val conf = sc.hadoopConfiguration
			val fs = FileSystem.get (conf)
			val files = fs.listStatus (new Path (path))
			files.filter (_.getLen () > 0).map (_.getPath ().toString)
		} catch {
			case e: Exception => Seq ("")
		}
	}

	// 주어진 List에서 중간값을 얻는다.
	def median (list : List[String]) : String = {
		val (lower, upper) = list.sortWith (_<_).splitAt (list.size / 2)
		if (list.size % 2 == 0)
			((lower.last.toDouble + upper.head.toDouble) / 2).toString
		else
			upper.head.toString
	}

	// 숫자를 두자리 수 시간으로 변경한다.
	def changeNumber (hour : Int) : String = {
		("%02d" format (hour))
	}
}
