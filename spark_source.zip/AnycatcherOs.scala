package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import	java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import	redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

object	AnycatcherOs {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	var redisKey : String = ""
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.info ("----------> start : AnycatcherOs")
		val spark = SparkSession.builder ()
					.appName ("AnycatcherOs")
					.getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.info ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-anycatcher1-os")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var stat_date = ""
		var hst_nm = ""
		var cpu = ""
		var memory = ""
		var swap = ""
		var mem_free = ""

		var tryCount = 1

		var offset = ""

		val jedis = new Jedis ("127.0.0.1", 6379);

		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val current = selectOneHour (sc, currentDate, hour, jedis, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var next = selectOneHour (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), jedis, spark)
		var medianValue = current.union (next)

		while (0 < count) {
			// topic OS 변수 - stat_date, hst_nm, cpu, memory, swap, mem_free
			var arrayOs : List [(String, String, String, String, String, String)] = List ()

			tryCount = 2
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(1000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					tryCount = 0
					for (record <- records.asScala) {
						val value = record.value ().replaceAll ("[\n\"{}]", "").split (",")
						cpu = ""
						memory = ""
						swap = ""
						mem_free = ""

						var count = 0
						for (one <- value) {
							val item = one.split (",")
							if (0 <= item(0).indexOf ("message:")) {
								val message = item(0).split (":")
								stat_date = message (1)
								count += 1
							} else if (1 <= count && count <= 5) {
								count match {
									case 1 => hst_nm = item(0)
									case 2 => cpu = item(0)
									case 3 => memory = item(0)
									case 4 => swap = item(0)
									case 5 => mem_free = item(0)
								}
								count += 1
							}
						}
						arrayOs = arrayOs :+ (stat_date
											  , hst_nm
											  , cpu
											  , memory
											  , swap
											  , mem_free)
					}
				}
			}
			processAnycatcherOs (sc, logger, jedis, arrayOs, medianValue)
			commitSync (consumer)
			count -= 1
			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY) 
			 && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1 = selectOneHour (sc, cal, cal.get (Calendar.HOUR_OF_DAY), jedis, spark)
				medianValue = next.union (next1)
				next = next1
			}
		}	
		consumer.close ()
		sc.stop ()
		jedis.close ()
		logger.warn ("----------> finish : AnycatcherOs")
	}

	// Anycatcher - os 처리
	def processAnycatcherOs (sc:SparkContext
							 , logger:org.apache.log4j.Logger
							 , jedis:redis.clients.jedis.Jedis
							 , arrayOs:List[(String,String,String,String,String,String)]
					  		 , medianValue:org.apache.spark.rdd.RDD [(String, (String, String, String, String))]) : Unit = {
		val parallel = sc.parallelize (arrayOs)

		// Pair RDD 생성
		var rdd = parallel.map (one => (one._1 + "|" + one._2, (one._3, one._4, one._5, one._6)))

		var max = rdd.reduceByKey ((v1, v2) => v1)

//		medianValue.collect.foreach (logger.warn)
		val join = max.join (medianValue)
/**
		val thread = new Thread (new AnycatcherOsThread (logger, join))	// Redis DB에 저장, UI에 전달 Thread
		thread.start
**/
		if (join.count == 0)
			max.collect.foreach (one => logger.warn (">>>>>>>> join == 0 | " + one))
		sendAnycatcherOs (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2._1.toInt < x._2._1._1.toInt)
			 || (x._2._2._2.toInt < x._2._1._2.toInt)
			 || (x._2._2._3.toInt < x._2._1._3.toInt)
			 || (x._2._2._4.toInt < x._2._1._4.toInt))
		})

		sendAnycatcherOsFault (logger, jedis, event)
/*
		val thread1 = new Thread (new AnycatcherOsFaultThread (logger, event))
*/
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.info ("CommitFailedException : " + e)
		}
	}

	def checkHour (hour : Int) : Boolean = {
		val current = Calendar.getInstance ()
		if (hour != current.get (Calendar.HOUR_OF_DAY) && (10 < current.get (Calendar.MINUTE)))
			false
		else
			true
	}

	def selectOneHour (sc:SparkContext
					   , calendar:Calendar
					   , hour:Int
					   , jedis:redis.clients.jedis.Jedis
					   , spark:org.apache.spark.sql.SparkSession)
					  : org.apache.spark.rdd.RDD [(String, (String, String, String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH)
				, hour)
/*
		jedis.select (10)
		val keys = jedis.keys (date).asScala

		var arrayOs : List [(String, String, String, String, String)] = List ()
		logger.warn ("selectOneHour : date : " + date + ", keys'size : " + keys.size)
		
		keys.foreach (one => {
			val list = jedis.lrange (one, 0, -1).asScala
			list.foreach (item => {
				val value = item.split ("=")
				if (value(0) == "os") {
					val string = value(1).toString.split (",")
					arrayOs = arrayOs :+ (one
										  , string(0)
										  , string(1)
										  , string(2)
										  , string(3))
				}
			})
		})
		jedis.close ();

		val parallel = sc.parallelize (arrayOs)
		var rdd = parallel.map (one => (one._1, (one._2, one._3, one._4, one._5)))
		logger.warn ("selectOneHour : rdd'size : " + rdd.count)
		rdd
*/
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-anycatcher1-os/" + date)
		val dataFrame = lines.select ("key", "cpu", "mem", "swap", "per")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString, one(3).toString, one(4).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}

	def sendAnycatcherOs (logger:org.apache.log4j.Logger, jedis:redis.clients.jedis.Jedis
                          , join:org.apache.spark.rdd.RDD [(String, ((String, String, String, String), (String,String,String,String)))]) : Unit = {
		if (join.count != 0) {
        	val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
        	val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

        	logger.warn ("AnycatcherOsThread'join : " + join.count)

			jedis.select (3)
        	join.collect.foreach (one => {
            	val key = one._1
            	val value = "\"Topic\":\"1-anycatcher1-os\",\"cpu\":\"" + one._2._1._1 + "\",\"avg_cpu\":\"" + one._2._2._1 + "\"," + "\"mem\":\"" + one._2._1._2 + "\",\"avg_mem\":\"" + one._2._2._2 + "\"," + "\"swap\":\"" + one._2._1._3 + "\",\"avg_swap\":\"" + one._2._2._3 + "\"," + "\"mem_free\":\"" + one._2._1._4 + "\",\"avg_mem_free\":\"" + one._2._2._4 + "\""
            	jedis.rpush (key, value)
				val split = one._1.split ("[|]+")
            	writer.write ( "{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\","  + value + "}\n")
            	writer.flush ()
			})
			writer.close ()
			socket.close ()
		}
	}

	def sendAnycatcherOsFault (logger:org.apache.log4j.Logger, jedis:redis.clients.jedis.Jedis
                          	   , event:org.apache.spark.rdd.RDD [(String, ((String, String, String, String), (String,String,String,String)))]) : Unit = {
		if (event.count != 0) {
			val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
			val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))

			jedis.select (1)                        // 1번 Anycatcher 실시간 장애

			logger.warn ("sendAnycatcherOsFault'event : " + event.count)
	
			event.reduceByKey ((v1, v2) => (v1))
			event.collect.foreach (one => {
				val key = one._1
				var value : String = ""
				if (one._2._2._1.toDouble < one._2._1._1.toDouble) {
					value = "CPU 측정값(" + one._2._1._1 + ")이 중간값(" + one._2._2._1 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._2.toDouble < one._2._1._2.toDouble) {
					value = "Memory 측정값(" + one._2._1._2 + ")이 중간값(" + one._2._2._2 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._3.toDouble < one._2._1._3.toDouble) {
					value = "SWAP 측정값(" + one._2._1._3 + ")이 중간값(" + one._2._2._3 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
				if (one._2._2._4.toDouble < one._2._1._4.toDouble) {
					value = "MAX(Swap) 측정값(" + one._2._1._4 + ")이 중간값(" + one._2._2._4 + ")보다 큽니다."
					saveDbAndUi (logger, jedis, writer, key, value)
				}
			})

			writer.close ()
			socket.close ()
		}
	}
	
	def saveDbAndUi (logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis 
					, writer:BufferedWriter
					, key:String
					, value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
        writer.write ( "{\"event_time\":\"" + split(0) + "\",\"Topic\":\"1-anycatcher1-fault\",\"hst_nm\":\"" + split(1) + "\"," + "\"source\":\"anycatcher\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (key + "," + value)
	}
}
