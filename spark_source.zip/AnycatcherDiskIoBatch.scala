package com.skcc.tqms

import java.util.Calendar
import scala.io.Source.fromFile
import scala.reflect.api.materializeTypeTag

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.hdfs.CannotObtainBlockLengthException
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.AnalysisException


import org.apache.spark._

object AnycatcherDiskIoBatch {
	val	BATCH_HOME = "/user/flume/kafka-data/1-anycatcher1-diskio/"
	def main(args : Array[String]) {
		@transient lazy val logger = Logger.getLogger(getClass.getName)

		var check = true

		val spark = SparkSession.builder()
			.appName("AnycatcherDiskIoBatch.scala")
			.master ("yarn")
			.getOrCreate()
  
		import spark.implicits._
		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
      
		
		// diskio, read, avg_disk_use_rate
		val tmp = List (("000000000", "0", "0", "0"))
		val para = sc.parallelize (tmp)

		// 7주 데이터 수집 - 시간대별로
	    for (index <- 0 to 23) {
			val currentDate = Calendar.getInstance ()
			currentDate.add (Calendar.DAY_OF_MONTH, 1)			// +1일 
			val baseDate = getBaseDate (currentDate)			// Key값으로 사용

			var aggregate = para.map (one => (one._1, List(one._2, one._3, one._4)))

			for (date <-1 to 7) {
				import org.apache.spark.SparkContext._
				import spark.implicits._
				import spark.sql
				import org.apache.spark.sql.functions._
				currentDate.add (Calendar.DAY_OF_MONTH, -3)
				val tmp1 = collectJsonFile (currentDate, spark, baseDate, logger, changeNumber (index))
				aggregate = aggregate.union (tmp1)
				logger.warn ("--------> aggregate'size : " + aggregate.count)
			}
			aggregate = aggregate.aggregateByKey(List[String]()) (
					(x, y) => x ::: List (y.toString)
					, (x1, y1) => x1 ::: y1)

			val medianRdd = aggregate.map (item => {
				val key = item._1
				if (key != "00000000000000") {
					val one = item._2(0)
					var diskIo : List [Int] = List ()
					var diskRead : List [Int] = List ()
					var avgDiskUseRate : List [Int] = List ()
					val regex = "\\]"
					val replace = one.replaceAll ("[List(]", "").replaceAll ("[ )]", "").replaceAll (regex, "")
					val split = replace.split (",")
					for (index <- 0 to (split.length / 3 - 1)) {
						diskIo = diskIo ::: List (split (index * 3).toInt)
						diskRead = diskRead ::: List (split (index * 3 + 1).toInt)
						avgDiskUseRate = avgDiskUseRate ::: List (split (index * 3 + 2).toInt)
					}
	
					val diskIo7 = median (diskIo)
					val diskRead7 = median (diskRead)
					val avgDiskUseRate7 = median (avgDiskUseRate)
					(key, List (diskIo7, diskRead7, avgDiskUseRate7))
				} else
					(key, List (0,0,0))
			})

			val tmp = medianRdd.map (one => {
				val key = one._1
				val diskIo = one._2(0)
				val diskRead = one._2(1)
				val diskUseRate = one._2(2)
				("{\"key\":\"" + key + "\",\"disk_io\":\"" + diskIo + "\",\"read\":\"" + diskRead + "\",\"avg_disk_use_rate\":\"" + diskUseRate + "\"}")
			})
			tmp.saveAsTextFile ("/user/spark/median/1-anycatcher1-diskio/" + baseDate + "/" + changeNumber (index))
		}
		sc.stop ()
	}

	// Kafka/토픽 디렉토리 일자별 디렉토리 이름
	def getDirectoryName (calendar:Calendar) : String = {
		("%s%02d%02d") format (calendar.get (Calendar.YEAR).toString.substring (2,4)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 새로운 중간값을 만들 일자의 연도/월/일 지정한다.
	def getBaseDate (calendar:Calendar) : String = {
		("%04d%02d%02d") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 한 개 파일을 JSON 형태로 읽고, RDD로 변환한다.
	def	collectJsonFile (currentDate:Calendar
						 , spark:org.apache.spark.sql.SparkSession
						 , baseDate:String
						 , logger:org.apache.log4j.Logger
						 , subDir:String) 
						 : org.apache.spark.rdd.RDD [(String, List[String])] = {
		var directoryName = getDirectoryName (currentDate) + "/" + subDir

		import spark.implicits._
		var dataFrame : org.apache.spark.sql.DataFrame = List (("00000000000000,0,0,0,0,0,0,0,0,0")).toDF ("message")
		val sc = spark.sparkContext
		var fileList = getAllFiles (BATCH_HOME + directoryName, sc)

		if (0 < fileList.size && (fileList (0) != "")) {
			fileList.foreach (one => {
				logger.warn (">>>>>>>>>>>>>> File : " + one + ", baseData : " + baseDate)
				val lines = spark.read.json (one)			// 파일에서 JSON형태로 읽는다.

				// JSON에서 message Column만 추출한다.
				try {
					dataFrame = dataFrame.union (lines.select ("message"))
				} catch {
					case e: AnalysisException => logger.warn ("cannot resolve 'message' given input columns")
				}
			})
		}
		logger.warn ("--------> dataFrame'size : " + dataFrame.count)
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => {
			val line = one.toString.split (",")
			(baseDate + line(0).substring (9) + "|" + line(1), List (line(2), line(3), line(4)))
		})
		rdd1
	}

	// 지정된 디렉토리안에 있는 모든 파일명을 얻는다.
	def getAllFiles (path:String, sc:SparkContext) : Seq [String] = {
		try {
			val conf = sc.hadoopConfiguration
			val fs = FileSystem.get (conf)
			val files = fs.listStatus (new Path (path))
			files.filter (_.getLen () > 0).map (_.getPath ().toString)
		} catch {
			case e: Exception => Seq ("")
		}
	}

	// 주어진 List에서 중간값을 얻는다.
	def median (list : List[Int]) = {
		val (lower, upper) = list.sortWith (_<_).splitAt (list.size / 2)
		if (list.size % 2 == 0)
			(lower.last + upper.head) / 2
		else
			upper.head
	}

	// 숫자를 두자리 수 시간으로 변경한다.
	def changeNumber (hour:Int) : String = {
		("%02d" format (hour))
	}
}
