import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;



public class AESTest {

	private Cipher aes = null;
	private SecretKeySpec 	key = null;
	private IvParameterSpec initalVector = null;
	
	/* AES STRING */
	public static final String SECURITY_ALGORITHM 		= "AES";				
	public static final String SECURITY_TRANSFORMATION	= "AES/CBC/PKCS5Padding"; 				
	public static final String AES_KEY_STR 				= "ce24c63d9cb81502374a60696eb31809";
	public static final String AES_INIT_STR 			= "8a5ef690f73782126975e50a4437de16";
	

	/**
	 * Description : Creates AESCipher Object.
	 * @param n/a n/a
	 * @return n/a n/a
	 * @throws Exception n/a 
	 */
	public AESTest() throws Exception {
		this.aes = Cipher.getInstance(SECURITY_TRANSFORMATION);
		this.key = new SecretKeySpec(this.hex2Bytes(AES_KEY_STR), SECURITY_ALGORITHM);
		this.initalVector = new IvParameterSpec(this.hex2Bytes(AES_INIT_STR));
	}
	
	/**
	 * Description : 문자열을 AES알고리즘으로 encrypt 하여 돌려 준다
	 * @param plain original text
	 * @return String AES알고리즘으로 encrypt 한 문자열
	 * @throws n/a n/a 
	 */
	public String encrypt(String plain) {
		byte[] content 		= null;
		byte[] cipherText 	= null;
		String encrypt 		= null;
		
		try {
			if (plain == null) return encrypt;
			content = plain.getBytes();
			aes.init(Cipher.ENCRYPT_MODE, this.key, this.initalVector);
			cipherText = aes.doFinal(content);
			encrypt = new String(Base64.encodeBase64(cipherText));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encrypt;

	}

	/**
	 * Description : AES알고리즘으로 encrypt한 문자열을 decrypt 하여 돌려 준다
	 * @param enctxt AES알고리즘으로 encrypt한 문자열
	 * @return String decrypt한 original text
	 * @throws n/a n/a 
	 */
	public String decrypt(String enctxt) {
		byte[] content 		= null;
		byte[] plainText 	= null;
		String decrypt 		= null;
		
		try {
			if (enctxt == null) return decrypt;
			content = enctxt.getBytes(); 
			aes.init(Cipher.DECRYPT_MODE, this.key, this.initalVector);
			plainText = aes.doFinal(Base64.decodeBase64(content));
			decrypt = new String(plainText, "UTF8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decrypt;
	}

	/**
	 * Description : hexa 코드 문자열을 바이트 형태의 배열로 돌려준다
	 * @param hex hexa 코드 문자열
	 * @return byte[] ascii 코드로 변환한 byte 배열
	 * @throws n/a n/a 
	 */
	private byte[] hex2Bytes(String hex) {
		byte[] b = null;
		int len = 0;
		try {
			len = hex.length();
			if (len % 2 == 1)
				return null;

			b = new byte[len / 2];
			for (int i = 0; i < len; i += 2) {
				b[i >> 1] = (byte) Integer.parseInt(hex.substring(i, i + 2), 16);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

}
