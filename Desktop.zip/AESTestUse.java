
public class AESTestUse {
	
	/**
	 *
	 * 통품감 DB계정들에 대한 암복호화 모듈 사용
	 */
	public static void main(String args[]) {
		
		AESTest aes = null;
		try {
			aes = new AESTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/* 문자열 설정 */
		String before_encrypt = "flghdud1234";
		String before_decrypt = "vC2MwmWM6CO5szciVKa3Nw==";
		
		/* Encrypt, Decrypt */
		System.out.println("Encrypt Result : " + aes.encrypt(before_encrypt));
		System.out.println("Decrypt Result : " + aes.decrypt(before_decrypt));
	}
}
