package com.skcc.tqms

import java.io.BufferedReader
import java.io.InputStreamReader

import redis.clients.jedis.Jedis
import scala.collection.mutable.HashMap
import scala.collection.JavaConversions._

import com.splunk.Service._
import com.splunk.ServiceArgs
import com.splunk.Args
import com.splunk.Job

object CollectThreshold {
    def main (args : Array[String]) : Unit = {

		val query = "search `TABLE_WAS_THREAD_DAY_LIMIT`"

		val connectionArgs : java.util.HashMap[String,Object] = new java.util.HashMap[String, Object]()
		val port = 8089
		connectionArgs.put ("host", "150.2.181.77")
		connectionArgs.put ("port", port:Integer)
		connectionArgs.put ("username", "portaldev")
		connectionArgs.put ("password", "portaldev")
		val splunkService = connect (connectionArgs)

		val job = splunkService.getJobs ().create (query, new Args ("exec_mode", "normal"))
		while (!job.isDone ())
			Thread.sleep (1000)
			
		job.finish ()
		val outputArgs = new Args ()
		outputArgs.add ("output_mode", "csv")
		outputArgs.add ("count", 10000)
		outputArgs.add ("offset", 0)

		val inputStream = job.getResults (outputArgs)
		val bufferedReader = new BufferedReader (new InputStreamReader (inputStream, "UTF-8"))
		var loop = true
		while (loop) {
			val one = bufferedReader.readLine ()
			if (one == null)
				loop = false
			else
				println ("One : " + one)
		}

		bufferedReader.close ()
		inputStream.close ()

/** Splunk 연결 정보
		val info = splunkService.getInfo

		val javaSet = info.keySet
		val scalaSet = javaSet.toSet

		for (key <- scalaSet)
			println (key + ":" + info.get(key))
**/
	}
	
/**
	def saveRedis (args : Araary[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
        var check = true
        var map = new java.util.HashMap[String, String]()
        var startTime = System.currentTimeMillis ()
        val limit = args (0).toInt
        var result : String = ""
        for (i <- 1 to limit) {
            map.clear ()
            map.put ("name", "server" + i.toString ())
            map.put ("cpu", (i % 100).toString ())
            map.put ("memory", (i % 100).toString ())
            map.put ("thread", (i % 100).toString ())
            result = jedis.hmset ("server" + i, map)
        }
        var finishTime = System.currentTimeMillis ()
        System.out.println ("HMSet Elapsed Time : " + (finishTime - startTime) / 1000f + "초")
        startTime = System.currentTimeMillis ()
        for (i <- 1 to limit) {
            jedis.hmget ("server" + i.toString (), "name", "cpu", "memory")
        }
        System.out.println ("Result : " + result)
        finishTime = System.currentTimeMillis ()
        System.out.println ("HMGet Elapsed Time : " + (finishTime - startTime) / 1000f + "초")
        for (i <- 1 to limit) {
            jedis.del ("server" + i.toString ())
        }
        jedis.close ();
    }
**/
}
