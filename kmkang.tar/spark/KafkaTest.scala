package	com.skcc.tqms

import org.apache.log4j.Logger
import org.apache.spark._
import org.apache.spark.sql.SparkSession
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010._
import scala.util.parsing.json._

object	KafkaTest {
	@transient lazy val logger = Logger.getLogger (getClass.getName)

	def main (args:Array[String]):Unit={
		val spark = SparkSession.builder ()
			    .appName ("KafkaTest")
			    .getOrCreate ()
		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val ssc = new StreamingContext (sc, Seconds(1))
		val topicsSet = Set ("syslog")
		val kafkaParams = Map [String,Object](
//			ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG -> "master.hadoop.com:9092,slave1.hadoop.com:9092,slave2.hadoop.com:9092",
			ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG -> "master.hadoop.com:9092,slave1.hadoop.com:9092",
			ConsumerConfig.GROUP_ID_CONFIG->"test-consumer-group",
			ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer],
			ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer])
		val messages = KafkaUtils.createDirectStream[String, String](
			ssc,
			LocationStrategies.PreferConsistent,
			ConsumerStrategies.Subscribe[String, String](topicsSet, kafkaParams))

		processMessage (messages)

// org.apache.spark.streaming.dstream.InputDStream[org.apache.kafka.clients.consumer.ConsumerRecord[String,String]]
		ssc.start
		ssc.awaitTermination
	}

	def processMessage (messages:org.apache.spark.streaming.dstream.InputDStream[org.apache.kafka.clients.consumer.ConsumerRecord[String,String]]):Unit = {
/*
		val lines = messages.map (_.value)
		val words = lines.flatMap (_.split(" "))

                wordCounts.foreachRDD((rdd, time:Time) => {
                        print ("time : " + time + ", rdd : ")
                        rdd.collect.foreach (logger.warn)
                })
                val wordCount = messages.reduceByKeyAndWindow (_+_, Seconds(120))
		val lines = messages.map (_.value)
*/
                messages.foreachRDD((rdd, time:Time) => {
                        logger.warn ("time : " + time + ", rdd : ")
			rdd.collect.foreach (one => {
				val jsonString = JSON.parseFull (one.value ())
				jsonString match {
					case Some (e) => {
						val result = e.asInstanceOf [Map[String, Any]]
						val message = result.get ("message")
						message match {
							case Some(e) => {
								val tokens = e.toString.split ("[|]+")
								var hst_nm = tokens (0)
								var stat_date = "20" + tokens(1)
								val cpuTmp = (100 - tokens (8).toDouble)
								var cpu = f"$cpuTmp%3.2f"
								val totalMem = tokens(10).toDouble
								val usedMem = tokens(11).toDouble
								val mem = usedMem * 100 / totalMem
								var memory = f"$mem%3.2f"
								val totalSwap = tokens (14).toDouble
								val usedSwap = tokens (15).toDouble
								val sw = (usedSwap * 100 / totalSwap)
								var swap = f"$sw%3.2f"
								logger.warn ("발생시간 : " + stat_date + ", 서버명 : " + hst_nm + ", CPU : " + cpu + ", 메모리 : " + memory + ", SWAP : " + swap)
							}
							case None => logger.warn ("Message Failed")
						}
					}
					case None => logger.warn ("jsonString Failed")
				}
			})
                })
	}
}
