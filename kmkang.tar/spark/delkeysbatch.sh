scala -cp /home/bigdata/spark:/home/bigdata/spark/jedis-2.4.2.jar DelKeysBatch >> /home/bigdata/log/delkeys.log
