#!/bin/bash

BEFORE1DAY=`date +%Y%m%d --date '1 days ago'`
hdfs dfs -rm  /user/spark/median/*/$BEFORE1DAY/*/*
hdfs dfs -rmdir  /user/spark/median/*/$BEFORE1DAY/*
hdfs dfs -rmdir  /user/spark/median/*/$BEFORE1DAY
