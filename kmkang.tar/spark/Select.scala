import redis.clients.jedis.Jedis
import scala.collection.JavaConverters._

object Select {
    def main (args : Array[String]) : Unit = {
        val jedis = new Jedis ("150.2.237.16", 6379);
//		for (index <- 1 until 15) {
		val index = 2								// Sysmaster 성능
		jedis.select (index)
		val keys = jedis.keys ("*").asScala	
		keys.foreach (one => {
			val list = jedis.lrange (one, 0, -1).asScala
			var dbpoolleak_avr = 0
			var dbpoolleak_max = 0
			var exec_cnt_avr = 0
			var exec_cnt_max = 0
			var avg_resp_time_avr = 0
			var avg_resp_time_max = 0
			var thread_avr = 0
			var thread_max = 0
			list.foreach (one => {
				if (0 <= one.indexOf ("dbpoolleak_avr"))
					dbpoolleak_avr += 1
				else if (0 <= one.indexOf ("dbpoolleak_max"))
					dbpoolleak_max += 1
				else if (0 <= one.indexOf ("exec_cnt_avr"))
					exec_cnt_avr += 1
				else if (0 <= one.indexOf ("exec_cnt_max"))
					exec_cnt_max += 1
				else if (0 <= one.indexOf ("avg_resp_time_avr"))
					avg_resp_time_avr += 1
				else if (0 <= one.indexOf ("avg_resp_time_max"))
					avg_resp_time_max += 1
				else if (0 <= one.indexOf ("thread_avr"))
					thread_avr += 1
				else if (0 <= one.indexOf ("thread_max"))
					thread_max += 1
			})
			if (1 < dbpoolleak_avr || 1 < dbpoolleak_max || 1 < exec_cnt_avr ||
			    1 < exec_cnt_max || 1 < avg_resp_time_avr || 1 < avg_resp_time_max ||
				1 < thread_avr || 1 < thread_max) {
				println ("Key : " + one)	
				printf ("dbpoolleak_avr = %d, dbpoolleak_max = %d, exec_cnt_avr = %d, exec_cnt_max = %d\n", dbpoolleak_avr, dbpoolleak_max, exec_cnt_avr, exec_cnt_max)
				printf ("avg_resp_time_avr = %d, avg_resp_time_max = %d, thread_avr = %d, thread_max = %d\n", avg_resp_time_avr, avg_resp_time_max, thread_avr, thread_max)
			}
		})
        jedis.close ();
    }
}
