spark-submit --driver-java-options "-Dlog4j.configuration=file:///home/bigdata/spark/log4j.diskio.properties"  --master yarn --deploy-mode client --executor-memory 20G spark/AnycatcherDiskIoBatch.jar
