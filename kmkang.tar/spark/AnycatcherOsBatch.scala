package com.skcc.tqms

import java.util.Calendar
import java.util.NoSuchElementException
import scala.io.Source.fromFile
import scala.reflect.api.materializeTypeTag

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Logger

import org.apache.spark._
import org.apache.spark.sql.AnalysisException

object AnycatcherOsBatch {
	val	BATCH_HOME = "/user/flume/kafka-data/syslog/"
	def main(args : Array[String]) {
		@transient lazy val logger = Logger.getLogger(getClass.getName)

		var check = true

		val spark = SparkSession.builder()
			.appName("AnycatcherOsBatch")
			.master ("yarn")
			.getOrCreate()
  
		import spark.implicits._
		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
      
		val tmp = List (("000000000", "0", "0", "0", "0"))
		val para = sc.parallelize (tmp)

		// 7주 데이터 수집
	    	for (index <- 0 to 23) {					// 0시부터 23시까지
			var aggregate = para.map (one => (one._1, List(one._2, one._3, one._4, one._5)))
			var currentDate = Calendar.getInstance ()
			currentDate.add (Calendar.DAY_OF_MONTH, 1)			// +1일
			val baseDate = getBaseDate (currentDate)			// Key값으로 사용
			currentDate.add (Calendar.DAY_OF_MONTH, -1)			// -1일
			for (date <- 1 to 7) {						// 7주
				import org.apache.spark.SparkContext._
				import spark.implicits._
				import spark.sql
				import org.apache.spark.sql.functions._
				currentDate.add (Calendar.DAY_OF_MONTH, -1)	// -1을 -7로 변경 필요
				val tmp1 = collectJsonFile (currentDate, spark, baseDate, logger, changeNumber (index))
				aggregate = aggregate.union (tmp1)
				aggregate = aggregate.filter (one => {
					(one.toString.indexOf ("000000000") < 0)
				})
			}
			aggregate = aggregate.aggregateByKey(List[String]()) (
					(x, y) => x ::: List (y.toString)
					, (x1, y1) => x1 ::: y1)
			logger.warn ("--------> aggregate'size : " + aggregate.count)
//			aggregate.collect.foreach (logger.warn)
//			try {
				val medianRdd = aggregate.map (item => {
					val key = item._1
					val one = item._2(0)
					var cpu : List [Double] = List ()
					var mem : List [Double] = List ()
					var swap : List [Double] = List ()
					var replace = one.replaceAll ("[List() ]", "")
					var split = replace.split (",")
					for (index <- 0 to (split.length / 3 - 1)) {
						cpu = cpu ::: List (split (index * 3).toDouble)
						mem = mem ::: List (split (index * 3 + 1).toDouble)
						swap = swap ::: List (split (index * 3 + 2).toDouble)
//						per = per ::: List (split (index * 4 + 3).toDouble)
					}
					val cpu7 = median (cpu)
					val mem7 = median (mem)
					val swap7 = median (swap)
					(key, List (cpu7, mem7, swap7))
				})
				val tmp = medianRdd.map (one => {
					val key = one._1
					val cpu = one._2(0)
					val mem = one._2(1)
					val swap = one._2(2)
					("{\"key\":\"" + key + "\",\"cpu\":\"" + cpu + "\",\"mem\":\"" + mem + "\",\"swap\":\"" + swap + "\"}")
				})
				tmp.saveAsTextFile ("/user/bigdata/median/syslog/" + baseDate + "/" + changeNumber (index))
//			} catch {
//				case e : Throwable => aggregate.collect.foreach (logger.warn)
//			}
		}

		sc.stop ()
	}

	// Kafka/토픽 디렉토리 일자별 디렉토리 이름
	def getDirectoryName (calendar:Calendar) : String = {
		("%s%02d%02d") format (calendar.get (Calendar.YEAR).toString.substring (2,4)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 새로운 중간값을 만들 일자의 연도/월/일 지정한다.
	def getBaseDate (calendar:Calendar) : String = {
		("%04d%02d%02d") format (calendar.get (Calendar.YEAR)
				, calendar.get (Calendar.MONTH) + 1
				, calendar.get (Calendar.DAY_OF_MONTH))
	}

	// 한 개 파일을 JSON 형태로 읽고, RDD로 변환한다.
	def	collectJsonFile (currentDate:Calendar
						 , spark:org.apache.spark.sql.SparkSession
						 , baseDate:String
						 , logger:org.apache.log4j.Logger
						 , subDir : String) 
						 : org.apache.spark.rdd.RDD [(String, List[String])] = {
		var directoryName = getDirectoryName (currentDate) + "/" + subDir

		import spark.implicits._
		var dataFrame : org.apache.spark.sql.DataFrame = List (("00000000000000||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1")).toDF ("message")
		val sc = spark.sparkContext
		var fileList = getAllFiles (BATCH_HOME + directoryName, sc)

		if (0 < fileList.size && (fileList(0) != "")) {
			fileList.foreach (one => {
				logger.warn (">>>>>>>>>>>>>> File : " + one + ", baseData : " + baseDate)
				if (one.toString.indexOf ("tmp") < 0) {
					val lines = spark.read.json (one)			// 파일에서 JSON형태로 읽는다.
	
					// JSON에서 message Column만 추출한다.
					try {
						dataFrame = dataFrame.union (lines.select ("message"))
					} catch {
						case e: AnalysisException => logger.warn ("cannot resolve 'message' given input columns")
					}
				}
			})
		}
		logger.warn ("--------> dataFrame'size : " + dataFrame.count)
		val rdd = dataFrame.rdd
		val rdd1 = rdd.filter (one => {
			(one.toString.indexOf ("00000000000000") < 0)
		})
		logger.warn ("--------> rdd1'size : " + rdd1.count)
/**
		rdd1.collect.foreach (one=>{
			logger.warn (one)
			val line = one.toString.split ("[|]+")
			logger.warn(line(8).toDouble + ", " + line(11).toDouble + ", " + line(15).toDouble)})
**/
		val rdd2 = rdd1.map (one => {
			val line = one.toString.split ("[|]+")
			val cpu = (100 - line(8).toDouble)
			val mem = (line(11).toDouble * 100 / line(10).toDouble)
			val swap = (line(15).toDouble * 100 / line(14).toDouble)
			(baseDate + line(1).substring (6) + "|" + line(0).substring(1), List (f"$cpu%3.2f", f"$mem%3.2f", f"$swap%3.2f"))
		})
//		rdd2.collect.foreach (println)
		rdd2
	}

	// 지정된 디렉토리안에 있는 모든 파일명을 얻는다.
	def getAllFiles (path:String, sc:SparkContext) : Seq [String] = {
		try {
			val conf = sc.hadoopConfiguration
			val fs = FileSystem.get (conf)
			val files = fs.listStatus (new Path (path))
			files.filter (_.getLen () > 0).map (_.getPath ().toString)
		} catch {
			case e: Exception => Seq ("")
		}
	}

	// 숫자를 두자리 수 시간으로 변경한다.
	def changeNumber (hour : Int) : String = {
		("%02d" format (hour))
	}

	// 주어진 List에서 중간값을 얻는다.
	def median (list : List[Double]) : Double = {
		val (lower, upper) = list.sortWith (_<_).splitAt (list.size / 2)
//		try {
			if (list.size % 2 == 0)
				(lower.last + upper.head) / 2
			else
				upper.head
//		} catch {
//			case e : NoSuchElementException => {
//			}
//		}
//		0
	}
}
