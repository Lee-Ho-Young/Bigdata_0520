package com.skcc.tqms

import  org.apache.log4j.Logger
import  org.apache.spark._
import  org.apache.spark.streaming._
import  org.apache.spark.sql.SparkSession

object Streaming {
        @transient lazy val logger = Logger.getLogger (getClass.getName)
        def main (args : Array[String]):Unit = {
		val spark = SparkSession.builder ()
                                        .appName ("Streaming")
                                        .getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN");
                val ssc = new StreamingContext (sc, Seconds(1))

                val lines = ssc.socketTextStream ("10.250.160.226", 19999)

		processLines (lines)
                ssc.start ()
                ssc.awaitTermination()
        }

	def processLines (lines:org.apache.spark.streaming.dstream.ReceiverInputDStream[String]) : Unit = {
                val wordCount = lines.flatMap (_.split(" ")).map((_, 1)).reduceByKeyAndWindow (_+_, Seconds(10))
//		wordCount.foreachRDD((rdd:org.apache.spark.rdd.RDD[(String, Int)], time:Time) => {
		wordCount.foreachRDD((rdd, time:Time) => {
			print ("time : " + time + ", rdd : ") 
			rdd.collect.foreach (logger.warn)
		})
	}
}
