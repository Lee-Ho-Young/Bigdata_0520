spark-submit --driver-java-options "-Dlog4j.configuration=file:///home/bigdata/spark/log4j.anycatcherosbatch.properties"  --master yarn --deploy-mode client spark/AnycatcherOsBatch.jar
