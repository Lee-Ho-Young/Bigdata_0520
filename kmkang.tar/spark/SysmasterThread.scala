package com.skcc.tqms

import	org.apache.log4j.Logger
import	java.util.Properties
import  java.util.Calendar
import  java.net.InetAddress
import  java.net.Socket
import  java.io.BufferedWriter
import  java.io.OutputStreamWriter

import	org.apache.spark.sql.SparkSession
import	org.apache.kafka.common.serialization.StringDeserializer
import	org.apache.kafka.clients.consumer._
import	org.apache.kafka.clients.consumer.KafkaConsumer
import	org.apache.kafka.clients.consumer.ConsumerRecords
import	org.apache.kafka.clients.consumer.ConsumerRecord

import	org.apache.spark._
import	org.apache.spark.streaming._
import	org.apache.spark.streaming.kafka010.KafkaUtils

import  redis.clients.jedis.Jedis
import	scala.collection.JavaConverters._

object	SysmasterThread {
	@transient lazy val logger = Logger.getLogger (getClass.getName)
	def main (args: Array[String]): Unit = {
		var conf: SparkConf = null

		logger.warn ("----------> start : SysmasterThread")
		val spark = SparkSession.builder ()
					.appName ("SysmasterThread")
					.master ("yarn")
					.getOrCreate ()

		val sc = spark.sparkContext
		sc.setLogLevel ("WARN")
		val props = new Properties ()
		props.put ("bootstrap.servers", "sd-mds-01.hadoop.com:6667,sd-mds-02.hadoop.com:6667")
		props.put ("key.deserializer", classOf [StringDeserializer])
		props.put ("value.deserializer", classOf [StringDeserializer])
		props.put ("enable.auto.commit", (false: java.lang.Boolean))
		props.put ("group.id", "test-consumer-group")
		props.put ("max.poll.records", (15000: java.lang.Integer))
		props.put ("auto.offset.reset", "earliest")		// earliest, latest

		logger.warn ("----------> group_id : test-consumer-group")	
		val consumer = new KafkaConsumer [String, String](props)
		val topics = Set ("1-sysmaster1-thread")
		consumer.subscribe (topics.asJava)

		import	org.apache.spark.internal.Logging

		// Topic 수집시 공통적으로 사용하는 변수
		var count = args (0).toInt
		var instnc = ""
		var hst_nm = ""
		var stat_date = ""
		var kind = ""

		// Thread에 관련된 변수 
		var max_thread = "0"
		var avg_thread = "0"

		// DBPoolLeak에 관련된 변수
		var lk_cnt = ""

		var checkTime = ""

		var offset = ""

		val currentDate = Calendar.getInstance
		var hour = currentDate.get (Calendar.HOUR_OF_DAY)
		val currentThread = selectOneHourThread (sc, currentDate, hour, spark)
		val currentDbPoolLeak = selectOneHourDbPoolLeak (sc, currentDate, hour, spark)
		currentDate.add (Calendar.HOUR_OF_DAY, 1)
		var nextThread = selectOneHourThread (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), spark)
		var nextDbPoolLeak = selectOneHourDbPoolLeak (sc, currentDate, currentDate.get (Calendar.HOUR_OF_DAY), spark)
		var medianValueThread = currentThread.union (nextThread)
		var medianValueDbPoolLeak = currentDbPoolLeak.union (nextDbPoolLeak)

		val jedis = new Jedis ("127.0.0.1", 6379);

		while (0 < count) {
			// topic Thread 변수
			var arrayThread : List [(String, String, String, String, String)] = List ()

			// topic dbpooleak 변수
			var arrayDbPoolLeak : List [(String, String, String, String)] = List ()
			
			var tryCount = 2
			while (0 < tryCount) {
				logger.warn ("I'm waiting......" + tryCount)
				val records = consumer.poll(1000)
				logger.warn ("records.count......" + records.count)
				if (records.count () == 0) {
					logger.warn ("tryCount : " + tryCount)
					tryCount = tryCount - 1
				} else {
					tryCount = 0
					for (record <- records.asScala) {
						offset = record.offset ().toString
						val value = record.value ().replaceAll ("[\n\"{}]", "").split (",")
						stat_date = ""
						instnc = ""
						hst_nm = ""
						lk_cnt = ""

						for (one <- value) {
							val item = one.split (":")
							item(0) match {
								case "avg_thread" => avg_thread = item(1)
								case "max_thread" => max_thread = item(1)
								case "instnc" => instnc = item(1)
								case "hst_nm" => hst_nm = item(1)
								case "lk_cnt" => lk_cnt = item(1)
								case "stat_date" => {
									stat_date = item(1)
								}
								case "type" => kind = item(1)
								case _ =>
							}
						}

						if (kind.substring (0, 6) == "thread"){		// Thread 저장
							arrayThread = arrayThread :+ (stat_date.substring (0, 12)
														  , hst_nm
														  , instnc
														  , max_thread			// max 값
														  , avg_thread)			// average 값
						} else if (0 <= kind.indexOf ("dbpoolleak"))	// DbPoolLeak 저장
							arrayDbPoolLeak = arrayDbPoolLeak :+ (stat_date.substring (0, 12)
														  , hst_nm
														  , instnc
														  , lk_cnt)			// dbpoolleak count
					}
				}
			}

			processSysmasterThread (sc, logger, jedis, arrayThread, medianValueThread)
			processSysmasterDbPoolLeak (sc, logger, jedis, arrayDbPoolLeak, medianValueDbPoolLeak)
			commitSync (consumer)

			val cal = Calendar.getInstance ()
			if (hour != cal.get(Calendar.HOUR_OF_DAY)
			 && (cal.get(Calendar.MINUTE) == 10)) {
				hour = cal.get(Calendar.HOUR_OF_DAY)
				cal.add (Calendar.HOUR_OF_DAY, 1)
				val next1Thread = selectOneHourThread (sc, cal, cal.get (Calendar.HOUR_OF_DAY), spark)
				medianValueThread = nextThread.union (next1Thread)
				nextThread = next1Thread

				val next1DbPoolLeak = selectOneHourDbPoolLeak (sc, cal, cal.get(Calendar.HOUR_OF_DAY), spark)
				medianValueDbPoolLeak = nextDbPoolLeak.union (next1DbPoolLeak)
				nextDbPoolLeak = next1DbPoolLeak
			}
			count -= 1
			logger.warn ("-------> Record 수 : " + arrayThread.size + ":" + arrayDbPoolLeak.size + ", count : " + count + ", offset : " + offset)
		}	
		consumer.close ()
		sc.stop ()
		jedis.close ()
		logger.warn ("----------> finish : SysMaster")
	}

	// SysmasterThread - Thread Cnt 처리
	def processSysmasterThread (sc:SparkContext
								, logger:org.apache.log4j.Logger
								, jedis:redis.clients.jedis.Jedis
								, arrayThread:List[(String,String,String,String,String)]
								, medianValue:org.apache.spark.rdd.RDD [(String, (String, String))])
		: Unit = {
		val parallel = sc.parallelize (arrayThread)

		// Pair RDD 생성
		var rdd = parallel.map (one => {
			(one._1.substring (0, 12) + "|" + one._2 + "|" + one._3, (one._4, one._5))
		})
		val join = rdd.join (medianValue)
		logger.warn ("processSysmasterThread'join : " + join.count)
		if (join.count == 0)
			rdd.collect.foreach (one => logger.warn (">>>>>>>> join == 0 | " + one))
		else 
			sendSysmasterThread (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2._1.toDouble < x._2._1._1.toDouble)
			 || (x._2._2._2.toDouble < x._2._1._2.toDouble))
		})
		if (0 < event.count)
			sendSysmasterThreadFault (logger, jedis, event)
	}

	// SysmasterThread - dbpoolleak cnt 처리
	def processSysmasterDbPoolLeak (sc:SparkContext
									, logger:org.apache.log4j.Logger
									, jedis:redis.clients.jedis.Jedis
									, arrayThread:List[(String,String,String,String)]
									, medianValue:org.apache.spark.rdd.RDD [(String, (String))])
		: Unit = {
		val parallel = sc.parallelize (arrayThread)

		// Pair RDD 생성
		var rdd = parallel.map (one => {
			(one._1.substring (0, 12) + "|" + one._2 + "|" + one._3, (one._4))
		})
		val join = rdd.join (medianValue)
		logger.warn ("processSysmasterDbPoolLeak'join : " + join.count)
		if (join.count == 0)
			rdd.collect.foreach (one => logger.warn (">>>>>>>> join == 0 | " + one))
		else 
			sendSysmasterDbPoolLeak (logger, jedis, join)

		// 측정치가 중간값보다 큰 경우 filter
		val event = join.filter (x => {
			((x._2._2.toDouble < x._2._1.toDouble))
		})
		if (0 < event.count)
			sendSysmasterDbPoolLeakFault (logger, jedis, event)
	}

	def checkHour (hour : Int) : Boolean = {
		val current = Calendar.getInstance ()
		if (hour != current.get (Calendar.HOUR_OF_DAY) && (10 < current.get (Calendar.MINUTE)))
			false
		else
			true
	}

	def selectOneHourThread (sc:SparkContext
							, calendar:Calendar
							, hour:Int
							, spark:org.apache.spark.sql.SparkSession)
							: org.apache.spark.rdd.RDD [(String, (String, String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-sysmaster1-thread/" + date)
		val dataFrame = lines.select ("key", "max_thread", "avg_thread")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString, one(2).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}	

	def selectOneHourDbPoolLeak (sc:SparkContext
								, calendar:Calendar
								, hour:Int
								, spark:org.apache.spark.sql.SparkSession)
								: org.apache.spark.rdd.RDD [(String, (String))] = {
		val date = ("%04d%02d%02d/%02d/*") format (calendar.get (Calendar.YEAR)
					, calendar.get (Calendar.MONTH) + 1
					, calendar.get (Calendar.DAY_OF_MONTH)
					, hour)
		logger.warn ("---------- Start Time ---------- date : " + date)
		val lines = spark.read.json ("/user/spark/median/1-sysmaster1-dbpoolleak/" + date)
		val dataFrame = lines.select ("key", "lk_cnt")
		val rdd = dataFrame.rdd
		val rdd1 = rdd.map (one => (one(0).toString, (one(1).toString)))
		logger.warn ("---------- Finish Time ---------- Size : " + rdd1.count)
		rdd1
	}	

	def sendSysmasterThread (logger:org.apache.log4j.Logger
							, jedis:redis.clients.jedis.Jedis
							, join:org.apache.spark.rdd.RDD [(String, ((String, String), (String,String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		logger.warn ("SysmasterThread'join : " + join.count)

		jedis.select (8)			// select 8번 Sysmaster Thread/DB Pool Leak 측정값
		join.collect.foreach (one => {
			val key = one._1
			val value = "\"max_thread\":\"" + one._2._1._1 + "\",\"avg_max_thread\":\"" + one._2._2._1 + "\",\"avg_thread\":\"" + one._2._1._2 + "\",\"avg_avg_thread\":\"" + one._2._2._2 + "\""
			jedis.rpush (key, value)
			val split = one._1.split ("[|]+")
			writer.write ("{\"event_time\":\"" + split(0) + "\",\"type\":\"real\",\"hst_nm\":\"" + split(1) + "\",\"instnc\":\"" + split(2) + "\",\"Topic\":\"1-sysmaster1-thread\"," + value + "}\n")
		})
		writer.close ()
		socket.close ()
	}

	def sendSysmasterDbPoolLeak (logger:org.apache.log4j.Logger
								, jedis:redis.clients.jedis.Jedis
								, join:org.apache.spark.rdd.RDD [(String, ((String), (String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		logger.warn ("Sysmaster DB Pool Leak'join : " + join.count)

		jedis.select (10)			// select 10번 SysmasterThread Thread/DB Pool Leak 측정값
		join.collect.foreach (one => {
			val key = one._1
			val value = "\"lk_cnt\":\"" + one._2._1 + "\",\"avg_lk_cnt\":\"" + one._2._2 + "\""
			jedis.rpush (key, value)
			val split = one._1.split ("[|]+")
			writer.write ("{\"event_time\":\"" + split(0) + "\",\"hst_nm\":\"" + split(1) + "\",\"type\":\"real\",\"instnc\":\"" + split(2) + "\",\"Topic\":\"1-sysmaster1-dbpoolleak\","  + value + "}\n")
		})
		writer.close ()
		socket.close ()
	}

	def sendSysmasterThreadFault (logger:org.apache.log4j.Logger
								  , jedis:redis.clients.jedis.Jedis
								  , event:org.apache.spark.rdd.RDD [(String, ((String, String), (String,String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		jedis.select (1)                        // 1번 Anycatcher 실시간 장애

		logger.warn ("sendSysmasterThreadFault'event : " + event.count)

		event.collect.foreach (one => {
			val key = one._1
			var value : String = ""
			if (one._2._2._1.toDouble < one._2._1._1.toDouble) {
				value = "max_thread 측정값(" + one._2._1._1 + ")이 중간값(" + one._2._2._1 + ")보다 큽니다."
				saveDbAndUi (logger, jedis, writer, key, value)
			}
			if (one._2._2._2.toDouble < one._2._1._2.toDouble) {
				value = "avg_thread 측정값(" + one._2._1._2 + ")이 중간값(" + one._2._2._2 + ")보다 큽니다."
				saveDbAndUi (logger, jedis, writer, key, value)
			}
		})
		writer.close ()
		socket.close ()
	}

	def sendSysmasterDbPoolLeakFault (logger:org.apache.log4j.Logger
								  	, jedis:redis.clients.jedis.Jedis
								  	, event:org.apache.spark.rdd.RDD [(String, ((String), (String)))]) : Unit = {
		val socket = new Socket (InetAddress.getByName ("150.2.237.16"), 8091)
		val writer = new BufferedWriter (new OutputStreamWriter (socket.getOutputStream ()))
		jedis.select (1)                        // 1번 Anycatcher 실시간 장애

		logger.warn ("sendSysmasterDbPoolLeakFault'event : " + event.count)

		event.collect.foreach (one => {
			val key = one._1
			var value : String = ""
			if (one._2._2.toDouble < one._2._1.toDouble) {
				value = "lk_cnt 측정값(" + one._2._1 + ")이 중간값(" + one._2._2 + ")보다 큽니다."
				saveDbAndUi (logger, jedis, writer, key, value)
			}
		})
		writer.close ()
		socket.close ()
	}

	def saveDbAndUi (logger:org.apache.log4j.Logger
					, jedis:redis.clients.jedis.Jedis
					, writer:BufferedWriter
					, key:String
					, value:String) : Unit = {
		val split = key.split ("[|]+")
		jedis.rpush (key, value)
		writer.write ( "{\"event_time\":\"" + split(0) + "\",\"Topic\":\"1-sysmaster-fault\",\"hst_nm\":\"" + split(1) + "\"," + "\"source\":\"SysmasterThread\",\"err_contents\":\"" + value + "\"}\n")
		logger.warn (key + "," + value)
	}

	def commitSync (consumer : KafkaConsumer [String, String]) : Unit = {
		import org.apache.kafka.clients.consumer.CommitFailedException
		try {
			consumer.commitSync ()
		} catch {
			case e: CommitFailedException => logger.warn ("CommitFailedException : " + e)
		}
	}
}
