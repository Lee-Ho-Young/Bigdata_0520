package com.skcc.tqms.main;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Enumeration;

import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import com.skcc.tqms.thread.PushThread;
import com.skcc.tqms.thread.SparkThread;

public class PushServer extends WebSocketServer {

	Hashtable<String, PushThread> hashTable = new Hashtable<String, PushThread>();

	public PushServer (int port) throws UnknownHostException {
		super(new InetSocketAddress(port));
	}

	public void onOpen(WebSocket conn, ClientHandshake handshake) {
		PushThread pushThread = new PushThread (conn);
		hashTable.put (conn.toString (), pushThread);
//		printHashtable ();
//		pushThread.start ();
		System.out.println ("!!!!!!!!!!! " + conn.toString () + ", hashTable.size () = " + hashTable.size());
		System.out.println(conn.getRemoteSocketAddress().getAddress().getHostAddress() + " entered the room!" );
	}

	public void onClose(WebSocket conn, int code, String reason, boolean remote) {
		PushThread pushThread = hashTable.get (conn.toString ());
		System.out.println(pushThread.getId () + " has left the room!(code : " + code + ", Reason : " + reason);
		onRemove (conn);
	}

	public void onMessage(WebSocket conn, String message) {
		PushThread pushThread = hashTable.get (conn.toString ());
		pushThread.receiveFromUI (message);
	}

	public void onFragment(WebSocket conn, Framedata fragment) {
		System.out.println("received fragment: " + fragment);
		onRemove (conn);
	}

	public void onError( WebSocket conn, Exception ex ) {
		ex.printStackTrace();
		if( conn != null ) {
			// some errors like port binding failed may not be assignable to a specific websocket
			System.out.println( conn + " has left the room!" );
			onRemove (conn);
		}
	}

	// UI와 연동하고 있는 Thread를 종료한다.
	public void onRemove (WebSocket conn) {
		PushThread pushThread = hashTable.get (conn.toString ());
		hashTable.remove (conn.toString ());
		conn.close ();
		pushThread.close ();
		pushThread = null;
	}

	public void onStart() {
		System.out.println("PushServer started!");
	}

	public void sendToAll(String text) {
//		printHashtable ();
		Collection<WebSocket> con = connections();
		synchronized (con) {
			for(WebSocket c : con) {
				String str = c.toString ();
//				str = str.substring (0, str.length() - 1);
				PushThread pushThread = hashTable.get (str);
				if (pushThread != null) {
					pushThread.sendToUI(text);
//					System.out.println ("^^^^^^^^^^^^ pushThread : " + text);
				} else {
//					System.out.println ("^^^^^^^^^^^^ pushThread : " + pushThread + ", c : " + str);
				}
			}
		}
	}
	
	public void printHashtable () {
		for (Enumeration e = hashTable.keys (); e.hasMoreElements ();)
			System.out.println ("$$$$$$$$$$ " + e.nextElement ());
	}

	public void printHexa (String message) {
		byte[]	hexa = message.getBytes();
		for (int index = 0; index < hexa.length; ++ index) {
			System.out.printf("%02x.", hexa [index]);
		}
	}

	static public void sleep (int waitingTime) {
		try {
			Thread.sleep(waitingTime);
		} catch (InterruptedException e) {
		}
	}
	
	static public String getDateSecond (Calendar calendar) {
        return String.format("%04d%02d%02d%02d%02d%02d", calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
	}

	public static void main( String[] args ) throws InterruptedException , IOException {
		WebSocketImpl.DEBUG = true;
		int port = 8090; // 843 flash policy port
		try {
			port = Integer.parseInt( args[ 0 ] );
		} catch ( Exception ex ) {
		}

		// UI와 연동할 WebSocket Server
		try {
			PushServer pushServer = new PushServer( port );
			pushServer.start();
			System.out.println( "PushServer started on port: " + pushServer.getPort() );

			// Spark와 연동할 TCP Server	
			ServerSocket	serverSocket = new ServerSocket (8091);
		
			while ( true ) {
//				sleep (10000);
				Socket	socket = serverSocket.accept ();
				SparkThread sparkThread = new SparkThread (pushServer, socket);
				sparkThread.start ();
			}
		} catch (Exception e) {
			System.out.println ("Exception : " + e);
		}
	}	
}
