import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Collection;

import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

public class WebSocketServerFault extends WebSocketServer {
	public WebSocketServerFault( int port ) throws UnknownHostException {
		super( new InetSocketAddress( port ) );
	}

	public WebSocketServerFault( InetSocketAddress address ) {
		super( address );
	}

	public void onOpen( WebSocket conn, ClientHandshake handshake ) {
		this.sendToAll( "new connection: " + handshake.getResourceDescriptor() );
		System.out.println( conn.getRemoteSocketAddress().getAddress().getHostAddress() + " entered the room!" );
	}

	public void onClose( WebSocket conn, int code, String reason, boolean remote ) {
		this.sendToAll( conn + " has left the room!" );
		System.out.println( conn + " has left the room!" );
	}

	public void onMessage( WebSocket conn, String message ) {
		this.sendToAll( conn, message );
		printHexa(message);
		System.out.println( conn + ": " + message );
	}

	public void onFragment( WebSocket conn, Framedata fragment ) {
		System.out.println( "received fragment: " + fragment );
	}


	public void onError( WebSocket conn, Exception ex ) {
		ex.printStackTrace();
		if( conn != null ) {
			// some errors like port binding failed may not be assignable to a specific websocket
		}
	}

	public void onStart() {
		System.out.println("Server started!");
	}

	/**
	 * Sends <var>text</var> to all currently connected WebSocket clients.
	 * 
	 * @param text
	 *            The String to send across the network.
	 * @throws InterruptedException
	 *             When socket related I/O errors occur.
	 */
	public void sendToAll( WebSocket source, String text ) {
		Collection<WebSocket> con = connections();
		synchronized ( con ) {
			for( WebSocket c : con ) {
				if (c != source)
					c.send( text );
			}
		}
	}

	public void sendToAll( String text ) {
		Collection<WebSocket> con = connections();
		synchronized ( con ) {
			for( WebSocket c : con ) {
				c.send( text );
			}
		}
	}
	
	public void usleep (int waitingTime) {
		try {
			Thread.sleep(waitingTime);
		} catch (InterruptedException e) {
		}
	}

	public void printHexa (String message) {
		byte[]	hexa = message.getBytes();
		for (int index = 0; index < hexa.length; ++ index) {
			System.out.printf("%02x.", hexa [index]);
		}
	}
	
	public String getDateSecond(Calendar calendar) {
		String second = String.format("%04d%02d%02d%02d%02d%02d", calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
		return second;
	}

	public String getDateMinute(Calendar calendar) {
		String minute = String.format("%04d%02d%02d%02d%02d00", calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE));
		return minute;
	}

	public String getDateHour(Calendar calendar) {
		String minute = String.format("%04d%02d%02d%02d0000", calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY));
		return minute;
	}

	public static void main( String[] args ) throws InterruptedException , IOException {
		WebSocketImpl.DEBUG = true;
		int port = 8887; // 843 flash policy port
		try {
			port = Integer.parseInt( args[ 0 ] );
		} catch ( Exception ex ) {
		}
		WebSocketServerFault s = new WebSocketServerFault( port );
		s.start();
		System.out.println( "ChatServer started on port: " + s.getPort() );

		BufferedReader sysin = new BufferedReader( new InputStreamReader( System.in ) );
		while ( true ) {
			usleep(1000);
			s.sendToAll ("Send All-connector to message (" + getDateSecond (Calendar.getInstance()) + ")");
		}
	}	
}

