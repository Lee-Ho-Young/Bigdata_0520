package com.skcc.tqms.thread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.java_websocket.WebSocket;
import com.skcc.tqms.main.PushServer;

//import redis.clients.jedis.Jedis;

public class SparkThread extends Thread {
	boolean check = true;
	Socket  socket;

	PushServer pushServer;
	BufferedReader	reader;

	public SparkThread (PushServer pushServer, Socket socket) {
		super ();
		this.socket = socket;
		this.pushServer = pushServer;
//		jedis = new Jedis ("150.2.237.16", 6379);
//		jedis.select (1);						// 1 : 실시간 장애
	}

	// Spark에서 전달된 실시간 장애 데이터를 UI에 보낸다.
	public void sendToUI (String message) {
		try {
			pushServer.sendToAll (message + "\n");
//			socket.flush ()
		} catch (Exception e) {
			System.out.println ("SparkThread.sendToUI Exception : " + e);
		}
	}

	public void close () {
//		jedis.close ();
		try {
			reader.close ();
			socket.close ();
		} catch (Exception e) {
			System.out.println ("SparkThread.close Exception : " + e);
		}
		System.out.println ("SparkThread.close");
	}

	public void run () {
		String one;
		try {
			reader = new BufferedReader (new InputStreamReader (socket.getInputStream ()));
		} catch (Exception e) {
			System.out.println ("SparkThread.run Exception : " + e);
			check = false;
		}
		int counter = 0;
		while (check) {
			try {
				one = reader.readLine ();
				if (one == null)
					break;
//				System.out.println (">>>>> SparkThread : " + one);
				++ counter;
				sendToUI (one);
			} catch (Exception e) {
				check = false;
				System.out.println ("SparkThread.run Exception : " + e);
			}
		}
		close ();
		System.out.println ("Counter : " + counter);
	}
}
