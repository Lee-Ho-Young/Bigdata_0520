package com.skcc.tqms.thread;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.java_websocket.WebSocket;

import redis.clients.jedis.Jedis;

public class PushThread extends Thread {
	String    uiId;
	String	  alarmServerName;
	String	  perfServerName;
	String	  uiKind;
	WebSocket webSocket;
	Jedis	  jedis;

	public PushThread (WebSocket webSocket) {
		super ();
		uiId = "";
		alarmServerName = "";
		perfServerName = "";
		uiKind = "";
		this.webSocket = webSocket;
		jedis = new Jedis ("150.2.181.64", 6379);
	}

	// Spark에서 전달된 실시간 장애 데이터를 UI에 보낸다.
	// 서버 Filtering 처리한다.
	public void sendToUI (String message) {
		if (compareServerName (message))
			webSocket.send (message + "\n");
//		webSocket.flush ()
	}

	public boolean compareServerName (String message) {
		String value = message.replaceAll ("[{}\"]", "");
		String type = "";
		String hstNm = "";
		StringTokenizer tokens = new StringTokenizer (value, ",");
		while (tokens.hasMoreTokens ()){
			String token = tokens.nextToken ();
			if (0 <= token.indexOf ("hst_nm"))
				hstNm = token.substring (7);
			else if (0 <= token.indexOf ("type"))
				type = token.substring (5);
		}
		if (type.equals ("P")) {
			if (0 <= perfServerName.indexOf (hstNm))
				return true; 
		} else if (type.equals ("A")) {
			if (alarmServerName.equals ("ALL"))
				return true;
			if (0 <= alarmServerName.indexOf (hstNm))
				return true;
		}
		return false;
	}

	// UI에서 전달된 메시지를 처리한다.
	// id 수신, 서버 변경
	// UI가 성능화면이고, 서버 변경시 성능 이력을 전달한다.
	public void receiveFromUI (String message) {
		boolean			uiChange = false;
//		System.out.println ("PushThread.receiveFromUI : " + message);
		StringTokenizer stringTokenizer = new StringTokenizer (message, ",");
		while (stringTokenizer.hasMoreTokens ()) {
			String			token = stringTokenizer.nextToken ();
			StringTokenizer tokens = new StringTokenizer (token, "=");
			String			token1 = tokens.nextToken ();
			String			token2 = tokens.nextToken ();
			if (token1.equals ("ID"))
				uiId = token2;
			else if (token1.equals ("AServer")) {
				alarmServerName = token2;
				uiKind = "A";
				uiChange = true;
			} else if (token1.equals ("PServer")) {
				perfServerName = token2;
				uiKind = "P";
				uiChange = true;
				changeUI ();
			} else if (token1.equals ("UIKind")) {
				uiKind = token2;
				uiChange = true;
			}
		}
//		System.out.println ("uiId : " + uiId + ", uiKind : " + uiKind + ", serverName : " + serverName);
		webSocket.send (message + "\n");
/*
		if (uiChange)			// UI가 성능 화면으로 변경된 경우, 성능 데이터를 조회
			changeUI ();
*/
	}

	// 지정된 서버의 성능 데이터를 조회한 후, UI로 보낸다.
	public void changeUI () {
		String	kind = "P";
		if (uiKind.equals ("F")) {				// 장애
			jedis.select (1);						// 1 : 실시간 장애
			kind = "F";
		} else
			jedis.select (3);						// 2 : 성능 데이터
		Calendar cal = Calendar.getInstance ();
		String date;
		cal.add (Calendar.HOUR_OF_DAY, -2);
		System.out.println ("-------- changeUI start");
		for (int index = 0; index < 120; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d00",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE)) + "|" + perfServerName;
			System.out.println ("-------- changeUI : " + date)
			List<String> value = jedis.lrange (date, 0, -1);
			if (value != null && value.size () != 0) {
				String tmp = value.get(0);
				if (tmp != null) {
					StringTokenizer	tokens = new StringTokenizer (date, "|");
					System.out.println ("{\"event_time\":\"" + tokens.nextToken ()
						  	+ "\",\"hst_nm\":\"" + tokens.nextToken () 
							+ "\",\"type\":\"P\","
							+ tmp + "}\n" );
/*
					sendToUI ("{\"event_time\":\"" + tokens.nextToken ()
						  	+ "\",\"hst_nm\":\"" + tokens.nextToken () 
							+ "\",\"type\":\"P\","
							+ tmp + "}\n" );
*/
				}
			}
			cal.add (Calendar.MINUTE, 1);
		}
	}

	public void close () {
		jedis.close ();
	}

/**
	public void run () {
	}
**/

	public String getUiId () { return uiId; }

	public static void main(String[] args) {
		Jedis jedis = new Jedis ("150.2.237.16", 6379);
		jedis.select (3);

		Calendar cal = Calendar.getInstance ();
		String date;
		cal.add (Calendar.HOUR_OF_DAY, -2);
		for (int index = 0; index < 120; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d00",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE));
			cal.add (Calendar.MINUTE, 1);
		}
		jedis.close();
	}
}
