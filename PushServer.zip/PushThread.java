package com.skcc.tqms.thread;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.java_websocket.WebSocket;

import redis.clients.jedis.Jedis;

public class PushThread extends Thread {
	String    uiId;
	String	  serverName;
	String	  uiKind;
	int		  select;
	WebSocket webSocket;
	Jedis	  jedis;

	List<String>	messageBuffer;
	boolean			checkMessage;

	public PushThread (WebSocket webSocket) {
		super ();
		uiId = "";
		select = 3;
		serverName = "";
		uiKind = "";
		messageBuffer = new ArrayList<String>();
		checkMessage = true;
		this.webSocket = webSocket;
		jedis = new Jedis ("150.2.181.64", 6379);
	}

	// Spark에서 전달된 실시간 장애 데이터를 UI에 보낸다.
	// 서버 Filtering 처리한다.
	public void sendToUI (String message) {
//		System.out.println ("SendToUI : " + message);
		if (filterUi (message)) {
			if (checkMessage)
				messageBuffer.add (message);			
			else
				webSocket.send (message + "\n");
		}
	}

	public boolean filterUi (String message) {
		String value = message.replaceAll ("[{}\"]", "");
		String type = "";
		String hstNm = "";

//		System.out.println ("FilterUI_1");
		if (uiId.equals ("") || uiId.equals ("None"))
			return false;

//		System.out.println ("FilterUI_2");
		if (serverName.equals ("") || serverName.equals ("None"))
			return false;

//		System.out.println ("FilterUI_3");
		StringTokenizer tokens = new StringTokenizer (value, ",");
		while (tokens.hasMoreTokens ()){
			String token = tokens.nextToken ();
			if (0 <= token.indexOf ("hst_nm"))
				hstNm = token.substring (7);
			else if (0 <= token.indexOf ("Topic"))
				type = token.substring (6);
		}
//		System.out.println ("uiId : " + uiId + ", type : " + type + ", IndexOf : " + uiId.indexOf (type));

		String compare = "";
		if ((0 <= type.indexOf ("fault"))
		 || (0 <= type.indexOf ("eventinfo"))) {
			if ((0 <= uiId.indexOf ("fault"))
			 || (0 <= uiId.indexOf ("eventinfo"))) {
				if (serverName.equals ("ALL"))
					return true;
				else if (serverName.equals (hstNm))
					return true;
				else
					return false;
			} else
				return false;
		} else {	
//			if (type.equals ("1-anycatcher1-diskusage"))
//				compare = "1-anycatcher1-diskio";
			if (type.equals ("1-sysmaster1-dbpoolleak"))
				compare = "1-sysmaster1-thread";
			else
				compare = type;
			if (uiId.indexOf (compare) < 0)
				return false;
		}

//		System.out.println ("serverName : " + serverName + ", hstNm : " + hstNm + ", indexOf : " + serverName.indexOf(serverName));
		if (serverName.indexOf (hstNm) < 0)
			return false;

//		System.out.println ("FilterUI_5");
		return true;
	}

	// UI에서 전달된 메시지를 처리한다.
	// id 수신, 서버 변경
	// UI가 성능화면이고, 서버 변경시 성능 이력을 전달한다.
	public void receiveFromUI (String message) {
		boolean			uiChange = false;
//		System.out.println ("PushThread.receiveFromUI : " + message);
		StringTokenizer stringTokenizer = new StringTokenizer (message, ",");
		while (stringTokenizer.hasMoreTokens ()) {
			String			token = stringTokenizer.nextToken ();
			StringTokenizer tokens = new StringTokenizer (token, "=");
			String			token1 = tokens.nextToken ();
			String			token2 = tokens.nextToken ();
			if (token1.equals ("Topic"))
				uiId = token2;
			else if (token1.equals ("Server")) {
				serverName = token2;
				uiChange = true;
			}
		}
//		System.out.println ("uiId : " + uiId + ", uiKind : " + uiKind + ", serverName : " + serverName + ", uiChange : " + uiChange);
//		webSocket.send (message + "\n");
		if (uiChange)			// UI가 성능 화면으로 변경된 경우, 성능 데이터를 조회
			changeUI ();
	}

	// 지정된 서버의 성능 데이터를 조회한 후, UI로 보낸다.
	public void changeUI () {
		checkMessage = true;
		if (uiId.equals ("1-anycatcher1-os"))
			sendAnycatcherOs ();
		else if (uiId.equals ("1-anycatcher1-diskio"))
			sendAnycatcherDiskInfo ();			// diskio와 diskusage를 같이 보냄
		else if (uiId.equals ("1-anycatcher1-networkio"))
			sendAnycatcherNetworkIo ();
		else if (uiId.equals ("1-ontunedb1-lastperf"))
			sendOntuneLastPerf ();
		else if (uiId.equals ("1-sysmaster1-thread"))
			sendSysmasterThread ();				// Thread와 DB Pool Leak을 같이 보냄
		else if (uiId.equals ("1-sysmaster1-resptime"))
			sendSysmasterRespTime ();
		else if (uiId.equals ("1-anycatcher1-fault")
			  || uiId.equals ("1-ontunedb1-fault"))
			sendFault ();
		checkMessage = false;
		for (String one : messageBuffer) {
			webSocket.send (one + "\n");
		}
		messageBuffer.clear ();
	}

	void sendAnycatcherOs () {
		jedis.select (3);					// UI에서 지정
		String error = "\"Topic\":\"1-anycatcher1-os\",\"cpu\":\"0\",\"avg_cpu\":\"0\",\"mem\":\"0\",\"avg_mem\":\"0\",\"swap\":\"0\",\"avg_swap\":\"0\",\"mem_free\":\"0\",\"avg_mem_free\":\"0\"";
		makeDataAndSendUI (jedis, error);
	}

	void sendAnycatcherDiskInfo () {
		jedis.select (4);					// Anycatcher Disk IO
		String error = "\"Topic\":\"1-anycatcher1-diskio\",\"disk_io\":\"0\",\"avg_disk_io\":\"0\",\"read\":\"0\",\"avg_read\":\"0\",\"disk_use_rate\":\"0\",\"avg_disk_use_rate\":\"0\"";
		makeDataAndSendUI (jedis, error);

/*
		jedis.select (5);					// Anycatcher Disk Usage
		error = "\"Topic\":\"1-anycatcher1-diskusage\",\"disk_io\":\"0\",\"avg_disk_io\":\"0\",\"disk_read\":\"0\",\"avg_disk_read\":\"0\",\"avg_disk_use_rate\":\"0\",\"avg_avg_disk_use_rate\":\"0\"";
		makeDataAndSendUI (jedis, error);
*/
	}

	void sendAnycatcherNetworkIo () {
		jedis.select (6);
		String error = "\"Topic\":\"1-anycatcher1-networkio\",\"networkio\":\"0\",\"avg_networkio\":\"0\"";
		makeDataAndSendUI (jedis, error);
	}

	void sendOntuneLastPerf () {
		jedis.select (7);
		String error = "\"Topic\":\"1-ontunedb1-lastperf\",\"cpu\":\"0\",\"avg_cpu\":\"0\",\"mem\":\"0\",\"avg_mem\":\"0\",\"swap_used\":\"0\",\"avg_swap_used\":\"0\",\"disk_io\":\"0\",\"avg_disk_io\":\"0\"";
		makeDataAndSendUI (jedis, error);
	}

	void sendSysmasterThread () {
		System.out.println (">>>> Call sendSysmasterThread.....");
		jedis.select (8);
//		String error = "\"Topic\":\"1-sysmaster1-thread\",\"max_thread\":\"0\",\"avg_max_thread\":\"0\",\"avg_thread\":\"0\",\"avg_avg_thread\":\"0\"";
		makeDataWithInstncAndSendUI (jedis, "1-sysmaster1-thread");

		jedis.select (10);
//		error = "\"Topic\":\"1-sysmaster1-dbpoolleak\",\"lk_cnt\":\"0\",\"avg_lk_cnt\":\"0\"";
		makeDataWithInstncAndSendUI (jedis, "1-sysmaster1-dbpoolleak");
	}

	void sendSysmasterRespTime () {
		System.out.println (">>>> Call sendSysmasterRespTime.....");
		jedis.select (9);
//		String error = "\"Topic\":\"1-sysmaster1-resptime\",\"avg_resp_time\":\"0\",\"avg_avg_resp_time\":\"0\",\"exec_cnt\":\"0\",\"avg_exec_cnt\":\"0\"";
		makeDataWithInstncAndSendUI (jedis, "1-sysmaster1-resptime");
	}

	void sendFault () {
		Calendar cal = Calendar.getInstance ();
		String date;
		cal.add (Calendar.HOUR_OF_DAY, -1);
		cal.add (Calendar.MINUTE, -1);
		List<String>	anycatcher = new ArrayList<String> ();
		List<String>	ontune = new ArrayList<String> ();
		String	oneEvent = "";
		jedis.select (1);
		for (int index = 0; index < 60; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d00",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE)); 
			List<String> value = jedis.lrange (date + "|" + serverName, 0, -1);
			for (String one : value) {
				String tmp = one;
				if (tmp != null) {
					oneEvent ="{\"event_time\":\"" + date + "\""
					  		+ ",\"hst_nm\":\"" + serverName + "\""
							+ tmp + "}";
				}
				anycatcher.add (oneEvent);
			}
			cal.add (Calendar.MINUTE, 1);
		}

		jedis.select (2);
		cal = Calendar.getInstance ();
		cal.add (Calendar.HOUR_OF_DAY, -2);
		cal.add (Calendar.MINUTE, -1);
		for (int index = 0; index < 120; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d00",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE)); 
			List<String> value = jedis.lrange (date + "|" + serverName, 0, -1);
			for (String one : value) {
				String tmp = one;
				if (tmp != null) {
					oneEvent ="{\"event_time\":\"" + date + "\""
					  		+ ",\"hst_nm\":\"" + serverName + "\""
							+ tmp + "}";
				} 
				ontune.add (oneEvent);
			}
			cal.add (Calendar.MINUTE, 1);
		}

		anycatcher.addAll (ontune);
		anycatcher.sort (Comparator.reverseOrder ());

		for (String event : anycatcher) 
			sendToUI (event);
	}

	void makeDataAndSendUI (Jedis jedis, String error) {
		Calendar cal = Calendar.getInstance ();
		String date;
		cal.add (Calendar.MINUTE, -31);
		for (int index = 0; index < 30; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d00",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE)); 
			List<String> value = jedis.lrange (date + "|" + serverName, 0, -1);
			if (value != null && value.size () != 0) {
				String tmp = value.get(0);
//				System.out.println ("tmp : " + tmp);
				if (tmp != null) {
					webSocket.send ("{\"event_time\":\"" + date + "\""
						  	+ ",\"hst_nm\":\"" + serverName + "\","
							+ tmp + "}" + "\n");
				} else {
					webSocket.send ("{\"event_time\":\"" + date
							+ "\"hst_nm\":\"" + serverName + "\","
							+ error + "}" + "\n");
				}
			} else {
				webSocket.send ("{\"event_time\":\"" + date + "\""
					  	+ ",\"hst_nm\":\"" + serverName + "\","
						+ error + "}" + "\n");
			}
			cal.add (Calendar.MINUTE, 1);
		}
	}

	void makeDataWithInstncAndSendUI (Jedis jedis, String topic) {
		Calendar cal = Calendar.getInstance ();
		String date;
		cal.add (Calendar.MINUTE, -31);
		List<String>	keys = new ArrayList<String>();
		for (int index = 0; index < 30; ++index) {
			date = String.format ("%04d%02d%02d%02d%02d",
					cal.get(Calendar.YEAR)
					, cal.get (Calendar.MONTH) + 1
					, cal.get (Calendar.DAY_OF_MONTH)
					, cal.get (Calendar.HOUR_OF_DAY)
					, cal.get (Calendar.MINUTE)); 
			System.out.println (">>>>>> SysmasterRespTime : " + date + "*");
			Set<String> tmp = jedis.keys (date + "*");
			for (String key : tmp) {
				if (0 <= key.indexOf (serverName))
					keys.add (key);
			}
			cal.add (Calendar.MINUTE, 1);
		}
		keys.sort (Comparator.naturalOrder());

		String serverName, instnc;
		StringTokenizer	tokens;
		for (String key : keys) {
			List<String> value = jedis.lrange (key, 0, -1);
			if (value != null && value.size () != 0) {
				String tmp = value.get(0);
				tokens = new StringTokenizer (key, "|");
				if (tokens.countTokens () == 3) {
					date = tokens.nextToken ();
					serverName = tokens.nextToken ();
					instnc = tokens.nextToken ();
					if (tmp != null) {
						webSocket.send ("{\"event_time\":\"" + date + "\","
							  	+ "\"hst_nm\":\"" + serverName + "\","
								+ "\"instnc\":\"" + instnc + "\","
								+ "\"type\":\"history\","
								+ "\"Topic\":\"" + topic + "\","
								+ tmp + "}" + "\n");
					}
				}
			}
		}
	}

	public void close () {
		jedis.close ();
	}

	public String getUiId () { return uiId; }
}
